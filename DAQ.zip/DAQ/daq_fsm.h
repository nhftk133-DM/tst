/////////////////////////////////////////////////////////////////////////
// daq_fsm.h
// core logic support to acquisition module

#ifndef __DAQ_FSM_H__
#define __DAQ_FSM_H__
#include "DAQTypes.h"

struct DAQ_STATE; 
#include "BSPLL.h"
#include "daq_queue.h"
#include "usbd_def.h"

#if defined  (__GNUC__)
  #define ALIGN4 __attribute__((aligned(4)))
#endif
//////////////////////////////////////////////////////
//state list - explained in DAQMain.cpp
typedef enum _DAQ_STATE_FSM {
	eDAQ_STATE_ZERO, 
	eDAQ_STATE_INIT,
	eDAQ_STATE_BEGIN_TESTCH10,
	eDAQ_STATE_RUN_TESTCH10, 
	eDAQ_STATE_IDLE,
	
	eDAQ_STATE_WAIT_HV, 
	eDAQ_STATE_WAIT_PWM, 
	eDAQ_STATE_REMOVE_ZEROS,
	eDAQ_STATE_RUN,
	
	eDAQ_STATE_RUN_WAIT,
	eDAQ_STATE_RUN_WAIT_USB_END,
	eDAQ_STATE_ENDXFER, 
	eDAQ_STATE_STOP,
	eDAQ_STATE_ERROR, 
} DAQ_STATE_FSM; 
//////////////////////////////////////////////
// logical inputs list
// Asynchronous events are stored in an "inputs" array and handled synchronously in the main loop
// 
typedef enum _DAQ_FSM_INPUT {
	eDAQStart = 0, //from host commands
	eDAQStop, //from host commands
	eDAQUSBReady, //USB ready to Xmit
	eDAQFIFOEF, //Ext FIFO empty - positive logic
	eDAQFIFOHF, //Exf FIFO half full - positive logic 
	eDAQFIFOAF, //Exf FIFO almost full - positive logic - unused
	eDAQFIFOFF, //Exf FIFO full - positive logic
	eDAQStartContinuous, //from host commands
	eDAQLASTINPUT
} DAQ_FSM_INPUT; 

uint8_t DAQInputTst(DAQ_FSM_INPUT eInput);
uint8_t DAQInputSet(DAQ_FSM_INPUT eInput);
uint8_t DAQInputClr(DAQ_FSM_INPUT eInput);

////////////////////////////////////////////
// DAQ_STATE holds core information available
// from several modules in the code
// It essentially holds several global variables in a 
// single place
// Warning: the alignment of variables 
// that are accessed directly by the USB is critical - 
// it MUST be 32 bits aligned 
typedef struct _DAQ_STATE {
	// DAQ_FSM outputs
	int mRunning;
	// DAQ_FSM state
	DAQ_STATE_FSM mCurrentState;
	// for usb - remove asap
	uint8_t mCurrentInterface; 
	// for USB - main structures
	USBD_HandleTypeDef *USBD_Device;
	//USB configuration params
	ALIGN4 uint32_t mUSBDMASize; 
	uint32_t mFIFOReadSize;
	//DAQ block counter

	ALIGN4 uint32_t mBlocksToTransfer;
	uint32_t mBlocksRead; 
	uint32_t mBlocksXfered; 
	uint32_t mBytesToTransfer; 
	uint32_t mBytesRead; 
	uint32_t mBytesXfered; 
	uint32_t mFlags; 
	//DAQ sw timers
	DAQSWTIMERHandle mDATATOut;
	ALIGN4 DAQDebugStatus mDebugStatus; 	

		// memory queues 
	DAQ_QUEUE_Handle mIMemQueue; 
	DAQ_QUEUE_Handle mOMemQueue; 
	DAQ_QUEUE_Handle mCurrQueue;

	// DAQ configuration parameters - from USB	   
ALIGN4	uint32_t mAcquisitionSize;
		uint32_t mAcquisitionTime; 
ALIGN4	uint16_t mPWMFrequency; 
		uint16_t mPWMPercentage; 
ALIGN4	uint8_t  mHVEnable; 
ALIGN4	uint8_t  mHVSetPoint; 
ALIGN4	uint8_t  mHVEnable2; 
ALIGN4	uint8_t  mHVSetPoint2; 

ALIGN4	uint8_t mDACWord; 
	// DAQ constants - from board
ALIGN4	int mVersion; 
ALIGN4	uint16_t mFWVersion; 

ALIGN4	uint8_t mEECmd; 
		uint8_t mEEAdd; 
		uint8_t mEEDataCnt; 	 	
ALIGN4	uint8_t mEERdBuffer[256];

ALIGN4  uint32_t mSPIWrite; 
ALIGN4  uint32_t mSPIRead; 

ALIGN4	uint8_t mGPIONum;
		uint8_t mGPIOVal;
ALIGN4  uint8_t mBank1Ena; 	 
} DAQ_STATE; 

DAQCALL_RESULT DAQInitState(USBD_HandleTypeDef *uh); 

//DAQCALL_RESULT DAQUpdateState(); 
void DAQNextState(DAQ_STATE_FSM nextstate); 
DAQ_STATE_FSM DAQCurrentState();

DAQDebugStatus DAQGetDebuStatus();  

void DAQSetDebugStatus(DAQDebugStatus ds);  
DAQDebugStatus DAQGetDebugStatus(); 
////////////////////////////////////////////////////
// Higher level functions between the board's BSP functions
// and the acquisition state machine
// 
void FSMResetAcquisitionState(); 
void FSMInitAcquisitionState();
void FSMEnableAcquisition(uint8_t ena);
uint8_t FSMReadIncomingFromFifo(); 

void FSMPWMEnable(uint8_t ena); 
void FSMHandleUSBTX(); 
void FSMKickWD(); 
void FSMStopAcquisition(); 
#endif
