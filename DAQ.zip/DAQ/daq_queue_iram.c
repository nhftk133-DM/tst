#include "BSPMain.h"
#include "daq_queue.h"

static DAQ_QUEUE queue_iram; 
//buffer queue memory. Built by stacking USB packets one near te other  
static uint8_t iram[QUEUE_NBUFS_IRAM][DAQ_STATE_FIFO_HF_SIZE+sizeof(DAQUSBDATAInfo)]; //memory used = QUEUE_NBUFS_IRAM *(DAQ_STATE_FIFO_HF_SIZE+sizeof(DAQUSBDATAInfo)) = 4 * (8192+16) = 32828 bytes
///////////////////////////////////////////////////////////////////////////////////////
//Initializes the buffer queue in internal RAM - unused - left for future use

DAQ_QUEUE_Handle DAQ_QUEUE_IRAM_Init(uint16_t bs)
{
	DAQ_QUEUE_Handle qh = &queue_iram; 
	int i; 
	qh->bs = bs; 
	qh->nb = QUEUE_NBUFS_IRAM; 
	for(i=0; i<qh->nb; i++) {
		qh->buf[i] = (DAQUSBDATAHandle)(iram[i]); 
		qh->buf[i]->blockInfo.dwSize = 0; 
		qh->buf[i]->blockInfo.dwCounter = 0; 
		qh->buf[i]->blockInfo.dwEvents = 0; 
		qh->buf[i]->blockInfo.eDBStatus = eDAQ_BS_VOID;	
	}
	DAQ_QUEUE_Init(qh); 
	return qh; 
}

////////////////////////////////////////////////////////////
// Used by BIT to test the queue's memory - returns the queue's base pointer a length
void DAQ_QUEUE_IRAM_GetMemory(uint32_t **mem, uint32_t* size) 
{
	*mem = (uint32_t*)iram;
	*size = QUEUE_NBUFS_IRAM * DAQ_STATE_FIFO_HF_SIZE / sizeof(uint32_t); 
}

