#ifndef __DAQ_QUEUE_H__
#define __DAQ_QUEUE_H__

#include <stm32f4xx_hal.h>
#include "DAQTypes.h" 

#define QUEUE_NBUFS_IRAM 4 //see notes in .c file
#define QUEUE_NBUFS_ORAM 4000 //see notes in .c file

//////////////////////////////////////////////////////
//cyclic queue of fixed size buffers
//written by the CPU from the external FIFO by DMA
//read by USB controller by USB DMA
typedef struct _DAQ_QUEUE {
	uint32_t bs; //single buffer size
	volatile uint32_t wp; //next buffer to fill
	volatile uint32_t rp; //current buffer to read
	uint32_t sz; //current queue size in bytes
	uint32_t nb;  //current number of blocks in the queue
	volatile uint32_t full; //no more buffers to fill 
	volatile uint32_t empty; //no buffers to read
	uint8_t cnt_empty; //if not zero, the queue underflew - for debugging
	uint8_t cnf_full;  //if not zero, the queue overflew - for debugging
	DAQUSBDATAHandle buf[QUEUE_NBUFS_ORAM]; //packet queue memory blocks
	DAQUSBDATAHandle voidbuf; //addtitional buffer -unused
} DAQ_QUEUE, *DAQ_QUEUE_Handle; 


DAQ_QUEUE_Handle DAQ_QUEUE_IRAM_Init(uint16_t bs); 
DAQ_QUEUE_Handle DAQ_QUEUE_ORAM_Init(uint16_t bs); 
void DAQ_QUEUE_Init(DAQ_QUEUE_Handle qh); 
DAQUSBDATAHandle DAQ_QUEUE_GetDAQBuf(DAQ_QUEUE_Handle qh); 
DAQUSBDATAHandle DAQ_QUEUE_GetEmptyDAQBuf(DAQ_QUEUE_Handle qh);
uint32_t DAQ_QUEUE_GetMaxBufSize(DAQ_QUEUE_Handle qh);
uint32_t DAQ_QUEUE_GetSize(DAQ_QUEUE_Handle qh); 
uint8_t DAQ_QUEUE_Full(DAQ_QUEUE_Handle qh);
uint8_t DAQ_QUEUE_Empty(DAQ_QUEUE_Handle qh);
void DAQ_QUEUE_IncReadPtr(DAQ_QUEUE_Handle qh);
void DAQ_QUEUE_IncWritePtr(DAQ_QUEUE_Handle qh); 
int32_t DAQ_QUEUE_XferData(DAQ_QUEUE_Handle qh, DAQDWORD nEvents, DAQDWORD eStatus, uint32_t dwbkCounter,  uint32_t size); 

#endif