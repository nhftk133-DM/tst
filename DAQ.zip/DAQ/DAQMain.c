#include <stm32f4xx_hal.h>
#include "BSPMain.h"
#include "daq_fsm.h" 
#ifdef __cplusplus
extern "C" {
#endif
////////////////////////////////////////////////////////////////////
//Runs every 10 ms. Used to update DAQSWTimer and DAQLed structure
void SysTick_Handler(void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
	DAQTimersUpdate(); 
	DAQLEDSUpdate(); 
}

#ifdef __cplusplus
};
#endif

#define MEM_TEST_BLOCK_SIZE 16384
////////////////////////////////////////////////
// DAQ FW entry point
// It is split in two logical parts: HW initialization and BIT
// main acquisition loop 
// The first part executes once after system reset, while the second executes indefinitely
// The boundary is the case eDAQ_STATE_INIT: a successful acquisition shall always return to this state. 
// A faulty acquisistion shall trap the main loop in the eDAQ_STATE_ERROR state. The loop will then recover
// only after receiving an INIT command from the host PC. 
int main(void)
{
	DAQLEDHandle lh1; 
	DAQLEDHandle usbled; 
	DAQLEDHandle memled;

	DAQSWTIMERHandle mDelayStartAcqTimer; //SW timer to allow HV generators to settle and delay acquisition start 
	DAQSWTIMERHandle mDelayPWMTimer; //PWM settling timer
	DAQSWTIMERHandle mAcquisitionTimeout; //Wait this time before declare acquisition failure. This is restarted every time the 
																				// Half-Full lfag of the FIFO toggles to valid state 
	DAQSWTIMERHandle mPerfMemory; 
	int usbdiv = 100; 
	int memdiv = 100; 
	int i,j;
//	uint8_t ddd[MEM_TEST_BLOCK_SIZE],nd=6; 
	uint32_t cm = 0,mbs = 0; 
	uint16_t a = 0x0363,b;  
	volatile uint32_t unused; 

	DAQCLKStart();  //selects the correct HOSC configuration -> 184 MHz. Other clocks in the system are integer fractions of this 
	BSPWDDisable(); //Disable WD while USB connection - it may take too much time and the system in not under the main loop control 
									//Along this period
	DAQUSBStart();  // Allows the USB stack to configure the device connection to a USB host 
	DAQNextState(eDAQ_STATE_ZERO); 

	DAQReset(); //Low level hardware initialization 
	BSPWDEnable(); //Release the WD counting
	
//	uint16_t data[] = { 0x00, 0x00 }; 
//	uint8_t t; 
//	uint16_t CpuAdd[] = { 13, 14 };
//	uint8_t n = 1; 
//	BSPEEWrite(CpuAdd[0], &data[0], &n);
//	BSPEEWrite(CpuAdd[1], &data[1], &n);

	BSPVerCpu('0', 'D');  //New function that writes to EEPROM address 13, 14 the .bin file Version (5/4/17)
	
	for(;;) 
	{
		BSPPollINTS();	//Check for external inputs - see in the function body 	
		FSMKickWD();  //WD is kicked every iteration
		//Manage the acquisition state machine. This is relevant for the data acquisition task. 
		//All the setup tasks, HW interaction of the host DLL with the firmware are done by interrupt handlers on the 
		//USB bus and described in the file usbd_WinbUSBComm.c / .h 
		switch(DAQCurrentState())
		{
			case eDAQ_STATE_ZERO: //SW resurces setup
				FSMResetAcquisitionState(); 
				lh1		 = DAQLEDAcquire(GPIO_PIN_6); //SW led managers - described in leds.c
				usbled = DAQLEDAcquire(GPIO_PIN_10); 
				memled = DAQLEDAcquire(GPIO_PIN_12);
				mDelayStartAcqTimer = DAQTimerGetTimer(); //SW timers - described in swtimer.c
				DAQTimerInit(mDelayStartAcqTimer, 1000, 0); 
				mDelayPWMTimer = DAQTimerGetTimer(); 
				DAQTimerInit(mDelayPWMTimer, 20, 0); 
				mAcquisitionTimeout = DAQTimerGetTimer();
				DAQTimerInit(mAcquisitionTimeout, 1000, 0);
				DAQNextState(eDAQ_STATE_BEGIN_TESTCH10);
				break; 
			case eDAQ_STATE_BEGIN_TESTCH10: //Finish BIT testing: start CH10 test sequence				
				FSMInitAcquisitionState();
				FSMEnableAcquisition(1); 
				BSPPWMSet(100,5);
				FSMPWMEnable(1);
				DAQTimerStart(mAcquisitionTimeout);
				 
				DAQNextState(eDAQ_STATE_RUN_TESTCH10);
				break; 
			case eDAQ_STATE_RUN_TESTCH10: //test CH10 acquisition 
				if (DAQTimerRoll(mAcquisitionTimeout))
				{					
					DAQSetDebugStatus(DAQ_STATUS_ACQ_NOT_STARTED); 
					DAQNextState(eDAQ_STATE_ERROR);					
				}
				if (DAQInputTst(eDAQFIFOHF))
				{
					DAQTimerStop(mAcquisitionTimeout);
					DAQInputClr(eDAQFIFOHF); 										 
					if (DAQInputTst(eDAQFIFOFF))
					{
						DAQInputSet(eDAQStop);						
						DAQSetDebugStatus(DAQ_STATUS_FIFO_OVERFLOW); 
						DAQLEDBlink(lh1, 500);
						DAQNextState(eDAQ_STATE_ERROR); 
					} 
					BSPCheckPMTCH10(0xa666, 0xd999);  //New Channel10 value for 10K Res to GND 30/3/17
					
					FSMEnableAcquisition(0);
					FSMPWMEnable(0);
					DAQNextState(eDAQ_STATE_INIT); 
				}				
				break; 
			case eDAQ_STATE_INIT: //Restore HW and SW resource to a known state
				FSMResetAcquisitionState();
				BSPADCStartAcquisition(0);
				BSPResetFifoAndCPLD(); 
				DAQLEDBlink(lh1, 2000); 
				DAQLEDSet(memled, 0);
				DAQLEDSet(usbled, 0);
				DAQNextState(eDAQ_STATE_IDLE); //and wait for start acquisition 
				DAQInputClr(eDAQStartContinuous);
				//DAQInputClr(eDAQStart); 
				break; 
			//Idle waiting for start acquisition command. Acquisition scenario must be previously defined by the host application. 
			//At acquisition start, all the parameters must be in place and the relative hardware must be already enabled
			//The state sequence is  
			//Setup and turn on the negative HV  eDAQ_STATE_IDLE (eDAQStart true)
			//Wait according to mDelayStartAcqTimer init value eDAQ_STATE_WAIT_HV
			//Start PWM and wait for it to settle eDAQ_STATE_WAIT_PWM
			case eDAQ_STATE_IDLE:
				if (DAQInputTst(eDAQStart)) 
				{	
					DAQLEDBlink(lh1, 2000);
					DAQInputClr(eDAQStart);
					DAQInputClr(eDAQUSBReady);  
					FSMInitAcquisitionState();
					 
					DAQTimerStart(mDelayStartAcqTimer); 
					DAQNextState(eDAQ_STATE_WAIT_HV);
				}				
				break; 
			case eDAQ_STATE_WAIT_HV:
				if (DAQTimerRoll(mDelayStartAcqTimer)) 
				{
					FSMEnableAcquisition(1); 
					DAQTimerStart(mDelayPWMTimer); 
					DAQNextState(eDAQ_STATE_WAIT_PWM);
				}
				break; 
			case eDAQ_STATE_WAIT_PWM:
				if (DAQTimerRoll(mDelayPWMTimer))
				{
					FSMPWMEnable(1);
					DAQTimerStart(mAcquisitionTimeout); 
					DAQNextState(eDAQ_STATE_REMOVE_ZEROS);				
				}
				break;
			case eDAQ_STATE_REMOVE_ZEROS: //After FIFO reset, we need to read it three times to get the first data out
				if (DAQTimerRoll(mAcquisitionTimeout))
				{
					DAQLEDBlink(lh1, 500);
					DAQSetDebugStatus(DAQ_STATUS_ACQ_NOT_STARTED); 
					DAQNextState(eDAQ_STATE_ERROR);
					DAQInputSet(eDAQStop);
				}
				if (DAQInputTst(eDAQFIFOHF))
				{
					unused = *(uint32_t*)FIFO_BASE_ADDR; 
					unused = *(uint32_t*)FIFO_BASE_ADDR; 
					unused = *(uint32_t*)FIFO_BASE_ADDR;
					DAQTimerStart(mAcquisitionTimeout);
					DAQNextState(eDAQ_STATE_RUN);
				}
				break; 
			case eDAQ_STATE_RUN:
				DAQLEDSet(memled, 0);
				if (DAQTimerRoll(mAcquisitionTimeout)) //Wait for data. If timer mAcquisitionTimeout rolls over, no data came in
				{
					DAQLEDBlink(lh1, 500);
					DAQSetDebugStatus(DAQ_STATUS_ACQ_NOT_STARTED); 
					DAQNextState(eDAQ_STATE_ERROR);
					DAQInputSet(eDAQStop);
				}

				if (DAQInputTst(eDAQStop)) //If we got eDAQStop command 
				{
					if (DAQInputTst(eDAQStartContinuous)) //If the acquistion was started as infinite acquisition
					{																			//eDAQStop is not an error
						DAQInputClr(eDAQStartContinuous); 
						DAQTimerStart(mDelayStartAcqTimer);
						FSMEnableAcquisition(0);
						FSMPWMEnable(0);
						DAQLEDSet(usbled, 1);
						FSMHandleUSBTX();
						DAQNextState(eDAQ_STATE_ENDXFER); 
					}
					else 
					{
						DAQLEDBlink(lh1, 500);							//but if not - it is !
						DAQSetDebugStatus(DAQ_STATUS_INTERRUPTED); 
						DAQNextState(eDAQ_STATE_ERROR); 
					}
				}

				if (DAQInputTst(eDAQFIFOHF)) //Do we have enough data in the main A/D FIFOs ? 
				{
					DAQInputClr(eDAQFIFOHF);  //Toggle the logical flag off
					DAQLEDSet(memled, 1);
					DAQTimerStart(mAcquisitionTimeout); //Restart the mACquisitionTimeout timer
					if (DAQInputTst(eDAQFIFOFF)) //BUT - we reached Fifo FULL state 
					{
						DAQInputSet(eDAQStop);	//Fail the acquisition
						DAQSetDebugStatus(DAQ_STATUS_FIFO_OVERFLOW); 
						DAQLEDBlink(lh1, 500);
						DAQNextState(eDAQ_STATE_ERROR); 
					}
					if (FSMReadIncomingFromFifo()) //DMA copy from external FIFO to external SDRAM. Tis function returns TRUE 
					{															//if all acquistion data has been received 
						FSMEnableAcquisition(0);		//Stop the acqusition HW
						FSMPWMEnable(0);						//Stop the PWM
						DAQNextState(eDAQ_STATE_RUN_WAIT_USB_END); //Wait for end of USB data transmission
					}
				}
				if (DAQInputTst(eDAQUSBReady)) //Anyway, if USB is ready to transmit
				{
					DAQLEDSet(usbled, 1); 
					FSMHandleUSBTX();		//transmit the data from external SDRAM to USB host
				}
				break; 
			case eDAQ_STATE_RUN_WAIT_USB_END:
				if (DAQInputTst(eDAQStop)) //if we got eDAQStop in this state do not fail the acquisition
				{
					DAQInputClr(eDAQStop);					
					DAQTimerStart(mDelayStartAcqTimer);
					DAQNextState(eDAQ_STATE_ENDXFER); //but terminate it gracefully
				} 
				else				
				{
					if (DAQInputTst(eDAQUSBReady)) //USB ready for TX
					{
						DAQInputClr(eDAQUSBReady); 					 
						DAQLEDSet(usbled, 1); 
						FSMHandleUSBTX(); //So TX data
					}
				}
				break; 
			case eDAQ_STATE_ENDXFER:
				if (DAQTimerRoll(mDelayStartAcqTimer)) //wait the mDelayStartAcqTimer and go to eDAQ_STATE_INIT
				{
					FSMStopAcquisition(); 
					DAQNextState(eDAQ_STATE_INIT);
				}
				break; 
			case eDAQ_STATE_ERROR: //error state. Fails the acquistion and forbids resuming it until the INIT command has been received
				FSMEnableAcquisition(0);
				FSMPWMEnable(0);
				FSMStopAcquisition(); 
				
				break; 
		}
	}
}