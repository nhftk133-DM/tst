#include "adc.h"

DAQADC adcs[NUM_ADC]; 

static uint32_t adc_current_channel = 0; 

static HAL_StatusTypeDef ADCInit(); 
static void DMAInit(); 

static ADC_HandleTypeDef hAdcHandle;

static ADC_HandleTypeDef hPOTAdcHandle;

static DMA_HandleTypeDef  hDMAAdc;


HAL_StatusTypeDef ADCRead(uint32_t channel);

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	adcs[adc_current_channel].value = HAL_ADC_GetValue(adcs[adc_current_channel].hADC);
	adcs[adc_current_channel].newRead = 1; 
//	HAL_ADC_Stop_IT(adcs[adc_current_channel].hADC);
//	adc_current_channel++; 
//	if (adc_current_channel == NUM_ADC)
//		adc_current_channel = 0;
	 
}

void ADC_IRQHandler(void)
{
  HAL_ADC_IRQHandler(adcs[adc_current_channel].hADC);
}

 
HAL_StatusTypeDef BSPADCInit()
{
	HAL_StatusTypeDef ret = ADCInit();
	if (ret != HAL_OK)
		return ret; 
	
	DAQADC *d; 
	d = &adcs[0]; 
	d->hADC = &hAdcHandle; 
	d->channel = HV_CHANNEL; 
	d->ena = 1; 
	d->value = 0; 
	d->newRead = 0; 

	d = &adcs[1]; 
	d->hADC = &hAdcHandle; 
	d->channel = HV2_CHANNEL; 
	d->ena = 1; 
	d->value = 0; 
	d->newRead = 0;
	

	d = &adcs[2]; 
	d->hADC = &hPOTAdcHandle; 
	d->channel = POT_CHANNEL; 
	d->ena = 1; 
	d->value = 0; 
	d->newRead = 0; 
	
	//ADCRead(0); 
	return HAL_OK; 
}


HAL_StatusTypeDef ADCInit()
{
	HAL_StatusTypeDef err; 

	memset(&hAdcHandle, 0, sizeof(ADC_HandleTypeDef)); 
	hAdcHandle.Instance          = DAQADC_HV;
  
  hAdcHandle.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV8;
  hAdcHandle.Init.Resolution = ADC_RESOLUTION12b;
  hAdcHandle.Init.ScanConvMode = DISABLE;
  hAdcHandle.Init.ContinuousConvMode = DISABLE;
  hAdcHandle.Init.DiscontinuousConvMode = DISABLE;
  hAdcHandle.Init.NbrOfDiscConversion = 0;
  hAdcHandle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hAdcHandle.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T1_CC1;
  hAdcHandle.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hAdcHandle.Init.NbrOfConversion = 1;
  hAdcHandle.Init.DMAContinuousRequests = DISABLE;
  hAdcHandle.Init.EOCSelection = DISABLE;


  err = HAL_ADC_Init(&hAdcHandle);
	if (err != HAL_OK)
		return err;

	memset(&hPOTAdcHandle, 0, sizeof(ADC_HandleTypeDef));
	hPOTAdcHandle.Instance          = DAQADC_POT;
  
  hPOTAdcHandle.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV8;
  hPOTAdcHandle.Init.Resolution = ADC_RESOLUTION12b;
  hPOTAdcHandle.Init.ScanConvMode = DISABLE;
	hPOTAdcHandle.Init.ContinuousConvMode = DISABLE;
  hPOTAdcHandle.Init.DiscontinuousConvMode = DISABLE;
  hPOTAdcHandle.Init.NbrOfDiscConversion = 0;
  hPOTAdcHandle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hPOTAdcHandle.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T1_CC1;
  hPOTAdcHandle.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hPOTAdcHandle.Init.NbrOfConversion = 1;
  hPOTAdcHandle.Init.DMAContinuousRequests = DISABLE;
  hPOTAdcHandle.Init.EOCSelection = DISABLE;
  err = HAL_ADC_Init(&hPOTAdcHandle);
//	if (err != HAL_OK)
	return err; 

}

HAL_StatusTypeDef ADCRead(uint32_t channel)
{
	ADC_ChannelConfTypeDef sConfig;
	HAL_StatusTypeDef err; 
	 
	DAQADC *d = &adcs[channel];
	adc_current_channel = channel;
	sConfig.Channel = d->channel;
	d->newRead = 0; 
	sConfig.Rank = 1; 
	sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES; 
	sConfig.Offset =0; 
	
	err = HAL_ADC_ConfigChannel(d->hADC, &sConfig); 
	if (err != HAL_OK)
		return err; 

	err = HAL_ADC_Start_IT(d->hADC);
	return err;
}

HAL_StatusTypeDef BSPADCRead(uint8_t chan, uint16_t *readout)
{
	int tout = 100 / 10; //msec / 10 msec/tick
	uint32_t sttime = HAL_GetTick();
	if (chan > NUM_ADC - 1)
		return HAL_ERROR; 
	if (adcs[chan].ena == 0)
		return HAL_ERROR; 
	ADCRead(chan);
	while (adcs[chan].newRead == 0 && HAL_GetTick() - sttime < tout);
	if (adcs[chan].newRead == 0)
		return HAL_ERROR; 
	*readout = adcs[chan].value;
	adcs[chan].value = 0;
	return HAL_OK; 
}

