#include "fw_version.h"
#include "BSPMain.h"
#include "daq_fsm.h" 
#include "usbd_WinUSBComm.h"

static uint8_t *DAQInputs; 
static DAQ_STATE g_DAQState; 
static uint8_t g_DAQInputs[eDAQLASTINPUT];

///////////////////////////////////////////////////////
// Layer between the main FSM, THE bsp layer and the 
// global configuration parameters
// Wraps several siomple processes to single function
// calls from the FSM, and uses global conf 
// parameters from the host


///////////////////////////////////////////////////////
//Resets all the global variable used by the FW 
DAQCALL_RESULT DAQInitState(USBD_HandleTypeDef *uh)
{
	DAQ_STATE * qs = &g_DAQState;  
	DAQInputs = g_DAQInputs;
	qs->mFWVersion = DAQ_FW_VERSION; 
	qs->mCurrentInterface = 0; 
	qs->mRunning = 0; 
	// DAQ_FSM inputs
	qs->mCurrentState = eDAQ_STATE_INIT;
	qs->mDebugStatus  = 0; 
	// for usb - remove asap
	qs->mCurrentInterface = 0; 
	//USB configuration params
	qs->mFIFOReadSize = DAQ_STATE_FIFO_HF_SIZE;
	qs->mUSBDMASize	  = qs->mFIFOReadSize + sizeof(DAQUSBDATAInfo); 
	
	// DAQ configuration parameters - from USB	 
	  
	qs->mAcquisitionSize	= 0;
	qs->mAcquisitionTime	= 0; 
	qs->mBank1Ena			= 0; 
	qs->mPWMFrequency		= 50; 
	qs->mPWMPercentage		= 50; 
	qs->mDACWord			= 0;

	qs->mBlocksToTransfer	= 0; 
	qs->mBytesToTransfer	= 0; 
	qs->mBlocksXfered		= 0;
	qs->mBytesXfered		= 0; 

	// DAQ constants - from board
	qs->mVersion			= 0; //update in a jiffie... 
	// memory queues 

	qs->mIMemQueue = DAQ_QUEUE_IRAM_Init(qs->mFIFOReadSize); 
	qs->mOMemQueue = DAQ_QUEUE_ORAM_Init(qs->mFIFOReadSize);

	//qs->mCurrQueue = qs->mIMemQueue;  
	qs->mCurrQueue = qs->mOMemQueue;  

	qs->USBD_Device = uh;
	qs->USBD_Device->pUserData = qs; 
}

DAQ_STATE_FSM DAQCurrentState() 
{
	return g_DAQState.mCurrentState; 
}

void DAQNextState(DAQ_STATE_FSM nextstate)
{
	g_DAQState.mCurrentState = nextstate; 
}
///////////////////////////////////////////////////
// error register - rexcords error in acquisition process
void DAQSetDebugStatus(DAQDebugStatus ds) 
{
	g_DAQState.mDebugStatus = ds;
}

DAQDebugStatus DAQGetDebugStatus() 
{
	return g_DAQState.mDebugStatus;
}

////////////////////////////////////////////////////////
// reads the resynchronized event inputs 
uint8_t DAQInputTst(DAQ_FSM_INPUT eInput)
{
	return DAQInputs[eInput]; 
}

uint8_t DAQInputSet(DAQ_FSM_INPUT eInput)
{
	uint8_t t = DAQInputs[eInput];
	DAQInputs[eInput] = 1; 
	return t; 
}

uint8_t DAQInputClr(DAQ_FSM_INPUT eInput)
{
	uint8_t t = DAQInputs[eInput];
	DAQInputs[eInput] = 0; 
	return t; 
}

/////////////////////////////////////////
//Resets logical queue and acquisition state 
void FSMResetAcquisitionState()
{
	DAQ_QUEUE_Init(g_DAQState.mIMemQueue); 
	DAQ_QUEUE_Init(g_DAQState.mOMemQueue); 
	g_DAQState.mBlocksRead	= 0; 
	g_DAQState.mBlocksXfered= 0;
	g_DAQState.mBytesRead	= 0; 
	g_DAQState.mBytesXfered	= 0;
	g_DAQState.mFlags		= 0; 
	g_DAQState.mRunning		= 0; 
}

////////////////////////////////////////////////////
// Inits acquisition state 
// Acquisition HW setup from setup
void FSMInitAcquisitionState()
{
	FSMResetAcquisitionState(); 
	g_DAQState.mRunning = 1;

	BSPHVEnable(0,g_DAQState.mHVEnable); 
	BSPHVSet(0, g_DAQState.mHVSetPoint); 
	if (g_DAQState.mBank1Ena) 
	{
		BSPHVEnable(1,g_DAQState.mHVEnable2); 
		BSPHVSet(1, g_DAQState.mHVSetPoint2); 
	}
	BSPADCStartAcquisition(0);

	BSPResetFifoAndCPLD();
	g_DAQState.mFlags = 0; 
	
	//DAQInputSet(eDAQUSBReady);
	
}

/////////////////////////////////////
//CPLD command to start acq from main FSM/////////
// 
void FSMEnableAcquisition(uint8_t ena)
{
	BSPADCStartAcquisition(ena);
}

///////////////////////////////////////////
// Reset HW at acq end
void FSMStopAcquisition()
{
	int i; 
	g_DAQState.mRunning = 0; 
	BSPHVEnable(0,0); 
	BSPHVEnable(1,0);
//	HAL_GPIO_WritePin(CPLD_RESET_PORT, CPLD_RESET_PIN, GPIO_PIN_RESET); 
//	for(i=0; i<15000; i++);
//	HAL_GPIO_WritePin(CPLD_RESET_PORT, CPLD_RESET_PIN, GPIO_PIN_SET); 
	//BSPResetFifoAndCPLD();

}

/////////////////////////
// Kick WD from main FSM 
void FSMKickWD() 
{
	BSPWDKick(); 
}

/////////////////////////////////////////////////////////
// Enable PWm with its parameters 
void FSMPWMEnable(uint8_t ena)
{
	if (ena)
		BSPPWMSet(g_DAQState.mPWMFrequency, g_DAQState.mPWMPercentage); 
	else 
		BSPPWMStop(); 
}

////////////////////////////////////////////////////
// Counts bytes transferred 
// builds up the data tx header
// and returns true
// when acquisition is done
// After first block, enables usb tx

uint8_t FSMReadIncomingFromFifo()
{
	DAQ_QUEUE_Handle q = g_DAQState.mCurrQueue;
	DAQDWORD dbs;
	DAQDWORD cts, tsz;
	DAQDWORD fifoflags; 
	uint32_t c; 
	DAQDWORD d; 
	if (DAQ_QUEUE_Full(q))
		return 0; 
	if ( g_DAQState.mBlocksRead == 0 )
		dbs = eDAQ_BS_FIRST; 
	else if ( g_DAQState.mBlocksRead == g_DAQState.mBlocksToTransfer-1 )
		dbs = eDAQ_BS_LAST;
	else 
		dbs = eDAQ_BS_RUN;
	//////////////////////////////////
	//do not allow acq to finish 
	if ( DAQInputTst(eDAQStartContinuous) )
	{
		tsz = q->bs;
		dbs = (dbs == eDAQ_BS_FIRST) ? dbs : eDAQ_BS_RUN;
		DAQ_QUEUE_XferData(q, BSPPWMEvents() , dbs, g_DAQState.mBlocksRead, tsz);
		g_DAQState.mBlocksRead++;
	}
	else 
	{
		if (g_DAQState.mAcquisitionSize > q->bs)
			tsz = q->bs;
		else 
			tsz = g_DAQState.mAcquisitionSize; 

		//g_DAQState.mBytesRead	 
		cts = DAQ_QUEUE_XferData(q, BSPPWMEvents(), dbs, g_DAQState.mBlocksRead, tsz);
		g_DAQState.mBlocksRead++; 
		g_DAQState.mBytesRead += cts; 
		g_DAQState.mAcquisitionSize -= cts;
	}
	if (dbs == eDAQ_BS_FIRST)
		DAQInputSet(eDAQUSBReady);
	fifoflags |= DAQInputTst(eDAQFIFOEF); 
	fifoflags <<=1;
	fifoflags |= DAQInputTst(eDAQFIFOHF); 
	fifoflags <<=1;
	fifoflags |= DAQInputTst(eDAQFIFOAF);
	fifoflags <<=1;
	fifoflags |= DAQInputTst(eDAQFIFOFF);
	g_DAQState.mFlags = fifoflags;
	if ( DAQInputTst(eDAQStartContinuous) )
		return 0; 
	return (dbs == eDAQ_BS_LAST); 
}


/////////////////////////////////////////////////
// unused
void EXTI2_IRQHandler(void)
{
	DAQInputSet(eDAQFIFOHF);
}

/////////////////////////////////////////////////
// unused
void EXTI3_IRQHandler(void)
{
	DAQLEDHandle lh = DAQLEDAcquire( GPIO_PIN_7);
	DAQLEDSet(lh, 1); 

	DAQInputSet(eDAQFIFOEF); 
}

/////////////////////////////////////////////////
// unused
void EXTI4_IRQHandler(void)
{
	DAQInputSet(eDAQFIFOAF); 
}

////////////////////////////////////////////////
// USB TX
// takes the first full block and sends it to
// USB. If no blocks available return 
// Counts bytes and terminates acquisition 
void FSMHandleUSBTX()
{
	DAQUSBDATA *buf;
	DAQ_QUEUE_Handle q = g_DAQState.mCurrQueue;
	if (g_DAQState.mRunning) {
		if (DAQ_QUEUE_Empty(q))
			return; 
		buf = DAQ_QUEUE_GetDAQBuf(q);
		
		g_DAQState.mBlocksXfered++; 
		if ( !DAQInputTst(eDAQStartContinuous) &&
			 (g_DAQState.mBlocksXfered == g_DAQState.mBlocksToTransfer) ) 
		{
			buf->blockInfo.eDBStatus = eDAQ_BS_LAST;
			DAQInputSet(eDAQStop); 			
		}	 
		DAQInputClr(eDAQUSBReady); 
		USBD_LL_Transmit(g_DAQState.USBD_Device, WINUSBCOMM_EPIN_ADDR, (uint8_t*)buf, q->bs+sizeof(DAQUSBDATAInfo));		
		g_DAQState.mBytesXfered += buf->blockInfo.dwSize; 
	} 
	else 
	{
		return;
	} 
}