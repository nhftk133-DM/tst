//////////////////////////////////////////////////////////
//BSPMAin.h
// Other helper functions
// Also includes BSPLL.h

#ifndef __BSP_MAIN_H__
#define __BSP_MAIN_H__
//#include 
 
#include "DAQTypes.h"
#include "daq_fsm.h" 
#include "BSPLL.h"


DAQCALL_RESULT DAQReset(); 
DAQCALL_RESULT DAQUSBStart(); 
DAQCALL_RESULT DAQCLKStart(); 

DAQCALL_RESULT DACInit(); 
DAQCALL_RESULT DACSet(float volts); 
DAQCALL_RESULT PWMInit(); 
DAQCALL_RESULT PWMSet(int freq, int pct); 
uint32_t PWMEvents(); 

DAQCALL_RESULT POTWrite(DAQWORD val);
DAQCALL_RESULT EEWrite(DAQWORD startAdd, DAQBYTE *data, DAQBYTE len); 
DAQCALL_RESULT EERead(DAQWORD startAdd, DAQBYTE *data, DAQBYTE len); 


#endif