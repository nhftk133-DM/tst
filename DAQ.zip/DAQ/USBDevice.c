#include "stm32f4xx_hal.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "BSPMain.h" 
//#include "usbd_BX.h"

#include "usbd_WinUSBComm.h"

USBD_HandleTypeDef USBD_Device;

//pseudo memory allocator used by the USB libraru=y
caddr_t _sbrk(int incr)
  {
    extern char __bss_end__;
    static char *heapEnd = &__bss_end__;

    char *previousHeapEnd = heapEnd;

    register caddr_t stackPointer asm ("sp");

    if (heapEnd + incr > stackPointer) {
//      _write(1, "Heap and stack collision\n", 25);
//      _exit(0);
    }

    heapEnd += incr;

    return (caddr_t) previousHeapEnd;
  }

extern PCD_HandleTypeDef hpcd;

//simple trick to call the same hanlder in both Full Speed USB and High Speed USB
#ifdef USE_USB_FS
void OTG_FS_IRQHandler(void)
#else
void OTG_HS_IRQHandler(void)
#endif
{
  HAL_PCD_IRQHandler(&hpcd);
}

