#ifndef __LEDS_H__
#define __LEDS_H__
#include <stm32f4xx_hal.h>
#include <stm32f4xx_hal_rcc.h>
#include "swtimer.h"

#define GPIO_LED_PORT  GPIOG
#define NLEDS 4

typedef struct DAQLEDTAG {
	uint16_t mGPIO; 
	uint16_t mON; 
	uint16_t mBlink; 
	DAQSWTIMERHandle mLEDTimer; 
} DAQLED; 

typedef uint8_t DAQLEDHandle; 
#define NOLED (DAQLEDHandle)(-1)
void						DAQLEDInit(); 
DAQLEDHandle		DAQLEDAcquire(uint16_t gpio);
DAQCALL_RESULT	DAQLEDSet(DAQLEDHandle lh, uint8_t on);
DAQCALL_RESULT	DAQLEDBlink(DAQLEDHandle lh, uint16_t period); 

void DAQLEDSUpdate(void); 

#endif 