

#ifndef __WD_H__
#define __WD_H__
#include <stm32f4xx_hal.h>
#include <stm32f4xx_hal_tim.h>
#include <stm32f4xx_hal_rcc.h>

#define WD_PORT GPIOG
#define WD_PIN  GPIO_PIN_2

 

#endif 