#include "BSPMain.h"
#include "daq_queue.h"

static DAQ_QUEUE queue_oram; 

////////////////////////////////////////////////////////////////////////////////////////////
//Initializes the buffer queue in the SDRAM. 
DAQ_QUEUE_Handle DAQ_QUEUE_ORAM_Init(uint16_t bs)
{
	DAQ_QUEUE_Handle qh = &queue_oram; 
	int i; 
	qh->bs = bs; 
	qh->nb = QUEUE_NBUFS_ORAM; //total memory used: QUEUE_NBUFS_ORAM *(DAQ_QUEUE_Handle::bs + sizeof(DAQUSBDATAInfo)) = 4000 *(16 + 8192) = 32832000 bytes
	for(i=0; i<qh->nb; i++) 
	{
		qh->buf[i] = (DAQUSBDATAHandle)(SDRAM_BASE_ADDR + i * (bs+sizeof(DAQUSBDATAInfo)));  //buffer pointer of size DAQ_QUEUE_Handle::bs + sizeof(DAQUSBDATAInfo)
		qh->buf[i]->blockInfo.dwSize = 0; //buffer size (from 0 to DAQ_QUEUE_Handle::bs
		qh->buf[i]->blockInfo.dwCounter = 0; //block ordinal counter
		qh->buf[i]->blockInfo.dwEvents = 0; //unused
		qh->buf[i]->blockInfo.eDBStatus = eDAQ_BS_VOID; //status	
	}
	DAQ_QUEUE_Init(qh); 
	return qh; 
}
