#include "DAQTypes.h"
#include "leds.h"
/////////////////////////////////////////////////
// leds.c
// Simple interface to turn on / off / blink board LEDs

DAQLED s_leds[NLEDS]; 
//////////////////////////////////////////////////
//CPU GPIO initialization
void DAQLEDInit()
{
	int i; 
	GPIO_InitTypeDef GPIO_InitStructure;
	uint16_t gpios[] = {GPIO_PIN_6, GPIO_PIN_7, GPIO_PIN_10, GPIO_PIN_12};  

	__GPIOG_CLK_ENABLE();
	GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStructure.Pull = GPIO_NOPULL;

	for(i=0; i<NLEDS; i++) {
		s_leds[i].mGPIO = gpios[i];
		s_leds[i].mLEDTimer = DAQTimerGetTimer(); 
		GPIO_InitStructure.Pin = gpios[i];
		HAL_GPIO_Init(GPIO_LED_PORT, &GPIO_InitStructure);
		DAQLEDSet(i,0); 
	}
}
////////////////////////////////////////////////////
//Allocate a LED. Uses a #define for the LED name on the board - luckily they are all 
//connected to the same GPIO port
DAQLEDHandle DAQLEDAcquire(uint16_t gpio)
{
	int i;
	for(i=0; i<NLEDS; i++)
		if (s_leds[i].mGPIO == gpio)
			return i; 
	return NOLED; 

}
/////////////////////////////////////////////////////////////////
//Turns LED on or off and stops its blinking state
DAQCALL_RESULT DAQLEDSet(DAQLEDHandle lh, uint8_t on)
{
	if (lh > NLEDS)
		return DAQCALL_RESULT_BADPARAMS; 
	s_leds[lh].mON = on; 
	s_leds[lh].mBlink = 0; 
	DAQTimerStop(s_leds[lh].mLEDTimer); 
	HAL_GPIO_WritePin(GPIO_LED_PORT, s_leds[lh].mGPIO  , s_leds[lh].mON ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

//////////////////////////////////////////////////////////////
//Blinks a LED. Every DAQLED has a built in SW timer used to blink a LED at
//a specific period
DAQCALL_RESULT DAQLEDBlink(DAQLEDHandle lh, uint16_t period)
{
	if (lh > NLEDS)
		return DAQCALL_RESULT_BADPARAMS; 
	s_leds[lh].mBlink = 1; 
	DAQTimerInit(s_leds[lh].mLEDTimer, period, 1); 
	DAQTimerStart(s_leds[lh].mLEDTimer); 
}

////////////////////////////////////////////////////////////////
// Called by SysTick handler. Blinks the blinking LED according to the timer state
void DAQLEDSUpdate(void)
{
	int i; 
	for(i=0; i<NLEDS; i++) {
		if (s_leds[i].mBlink && DAQTimerRoll(s_leds[i].mLEDTimer)) {
			s_leds[i].mON = ! s_leds[i].mON; 
			HAL_GPIO_WritePin(GPIO_LED_PORT, s_leds[i].mGPIO  , s_leds[i].mON ? GPIO_PIN_RESET : GPIO_PIN_SET);
		}
	}
}
