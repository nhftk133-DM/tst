#ifndef __SWTIMER_H__
#define __SWTIMER_H__
#include "stm32f4xx_hal.h"
#include <stm32f4xx_hal_rcc.h>

#define NSWTIMERS 16
#define NOTIMER ((uint8_t)(-1))

typedef struct DAQSWTIMERTAG {
	uint32_t mAllocated; 
	uint32_t mEnabled; 
	uint32_t mPeriodic; 
	uint32_t mLen; 
	uint32_t mCount; 
	uint32_t mRolled; 
} DAQSWTIMER; 

typedef uint8_t DAQSWTIMERHandle; 

 
DAQSWTIMERHandle DAQTimerGetTimer();
DAQCALL_RESULT DAQTimerInit(uint8_t timer, uint32_t len, uint32_t periodic);  
DAQCALL_RESULT DAQTimerStart(uint8_t timer);  
uint8_t DAQTimerRoll(uint8_t timer); 
DAQCALL_RESULT DAQTimerStop(uint8_t timer);  

void DAQTimersInit(void); 
void DAQTimersUpdate(); 

#endif