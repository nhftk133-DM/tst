#ifndef __EXTFIFO_H__
#define __EXTFIFO_H__
#include "BSPMain.h"
#include "BSPLL.h"
/* Includes ------------------------------------------------------------------*/
#include <stm32f4xx_hal.h>
#include <stm32f4xx_hal_rcc.h>
//////////////////////////////////////////////////////////////
//external FIFO and CPLD control pins renamed - ref board's schematics
#define CPLD_RESET_PORT GPIOJ
#define CPLD_RESET_PIN  GPIO_PIN_2
#define CPLD_SOC_PORT GPIOJ
#define CPLD_SOC_PIN  GPIO_PIN_0
#define FIFO_RESET_PORT GPIOK
#define FIFO_RESET_MRS GPIO_PIN_3
#define FIFO_RESET_PRS GPIO_PIN_4

HAL_StatusTypeDef BSPFMCInit(); 
HAL_StatusTypeDef BSPInitSDRAM();
HAL_StatusTypeDef BSPFMCStartMove(uint8_t *dest, uint32_t sz); 
HAL_StatusTypeDef BSPFMCEndMove(); 



#endif