#ifndef __ADC_H__
#define __ADC_H__
#include <stm32f4xx_hal.h>
#include <stm32f4xx_hal_rcc.h>
////////////////////////////////////////////////////////////////
// #define renaiming for DAQ hardware resources
#define DAQADC_HV ADC1
#define DAQADC_POT ADC3

#define ADC_HV_READ  0 
#define ADC_HV2_READ 1

#define NUM_ADC 3 

#define DAQ_ADC_GPIO_PORT GPIOA
#define DAQ_ADC_GPIO_PIN1 

//#define DAQDMA_CLK_ENABLE()               __DMA2_CLK_ENABLE()
#define DAQADC_FORCE_RESET()              __ADC_FORCE_RESET()
#define DAQADC_RELEASE_RESET()            __ADC_RELEASE_RESET()

/* Enable GPIOA HV (ADC1)*/
#define DAQADC_CLK_ENABLE()               __ADC1_CLK_ENABLE()
#define DAQADC_GPIO_CLK_ENABLE()          __GPIOA_CLK_ENABLE()


/* Definition for ADCx Channel Pin */
#define HV_CHANNEL_PIN                   GPIO_PIN_1
#define HV2_CHANNEL_PIN		             GPIO_PIN_2
#define HV_GPIO_PORT                     GPIOA

/* Enable GPIOA HV (ADC1)*/
#define POT_ADC_CLK_ENABLE()            __ADC3_CLK_ENABLE()
#define POT_ADC_GPIO_CLK_ENABLE()       __GPIOF_CLK_ENABLE()

#define POT_CHANNEL_PIN                 GPIO_PIN_10
#define POT_GPIO_PORT                   GPIOF


/* Definition for ADCx's Channel */
#define HV_CHANNEL						ADC_CHANNEL_1
#define HV2_CHANNEL                     ADC_CHANNEL_2
#define POT_CHANNEL						ADC_CHANNEL_8

/////////////////////////////////////////////////////
// Used to manage the above A/D channels
typedef struct DAQADCTAG_
{
	uint32_t channel; 
	ADC_HandleTypeDef *hADC; 
	uint8_t ena;  
	uint8_t newRead; 
	uint16_t value; 	
} DAQADC; 


HAL_StatusTypeDef BSPADCInit(); 
HAL_StatusTypeDef BSPADCStart(uint8_t chan); 
HAL_StatusTypeDef BSPADCRead(uint8_t chan, uint16_t *readout); 
void BSPADCScan(); 

#endif