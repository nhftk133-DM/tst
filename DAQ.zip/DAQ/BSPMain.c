#include "stm32f4xx_hal_conf.h"
#include <stm32f4xx_hal.h>

#include "DAQDLL.h"
#include "BSPMain.h"
#include "BSPLL.h" 

static void SystemClock_Config(void); 

DAQCALL_RESULT DAQCLKStart()
{
	HAL_Init(); 
	SystemClock_Config();
	return DAQCALL_RESULT_SUCCESS;
}

//extern uint32_t  _stext[], __stext[],_etext[], __etext[], _sdata[], _edata[];

uint32_t PWMEvents()
{
	return BSPPWMEvents(); 
}

//DAQCALL_RESULT BSPCheckFLASHCrc32(void)
//{
//        uint32_t end;
//        uint32_t crc;
//		uint32_t uwCRCValue;
//		CRC_HandleTypeDef  CrcHandle;
//		__CRC_CLK_ENABLE(); 
//		CrcHandle.Instance = CRC;
//		if(HAL_CRC_Init(&CrcHandle) != HAL_OK)
//		{
//			return DAQCALL_RESULT_CATASTROPHIC;
//		}
//
//        /* end is what the linker thinks is the end of the image. 
//            We later add one word to include the crc. */
//        end= (uint32_t)((uint32_t)&__etext  - (uint32_t)&__stext + (uint32_t)&_edata - 
//                (uint32_t)&_sdata); //
//		uwCRCValue = HAL_CRC_Accumulate(&CrcHandle, __stext, end/4+1);
//		
//        return uwCRCValue == 0 ? HAL_OK : HAL_ERROR;
//}



// Checks external hardware and internal flash
DAQCALL_RESULT DAQReset()
{
	//REPORT_ON_ERROR(BSPUSBStart()		!= HAL_OK, DAQ_STATUS_HW_GENERAL);
	BSPWDDisable(); 
	BSPI2CInit(); 
	REPORT_ON_ERROR(BSPEECheck()		!= HAL_OK, DAQ_STATUS_HW_EEPROM); 
	REPORT_ON_ERROR(BSPPWMInit()		!= HAL_OK, DAQ_STATUS_HW_GENERAL); 
	REPORT_ON_ERROR(BSPDACInit()		!= HAL_OK, DAQ_STATUS_HW_GENERAL); 
	REPORT_ON_ERROR(BSPADCInit()		!= HAL_OK, DAQ_STATUS_HW_GENERAL); 
	DAQTimersInit(); 
	DAQLEDInit(); 
	/*REPORT_ON_ERROR*/(BSPHVInit(0)			!= HAL_OK, DAQ_STATUS_HW_HV);	 //Remove only Error Report HV0 Maor(23/10/17)
	/*REPORT_ON_ERROR*/(BSPHVInit(1)			!= HAL_OK, DAQ_STATUS_HW_HV2);   //Remove only Error Report HV1 - SiPM HV Maor(23/10/17)
	REPORT_ON_ERROR(BSPMAX_SPIIinit()	!= HAL_OK, DAQ_STATUS_HW_GENERAL); 
	REPORT_ON_ERROR(BSPFMCInit()			!= HAL_OK, DAQ_STATUS_HW_IRAM);  // Checked changing manually one of the values in the IRAM
	REPORT_ON_ERROR(BSPInitSDRAM()		!= HAL_OK, DAQ_STATUS_HW_SDRAM); // Checked changing manually one of the values in the SDRAM
	REPORT_ON_ERROR(BSPGPIOInit()			!= HAL_OK, DAQ_STATUS_HW_GENERAL);
	REPORT_ON_ERROR(BSPExtIntInit()		!= HAL_OK, DAQ_STATUS_HW_GENERAL); 
	//REPORT_ON_ERROR(BSPCheckFLASHCrc32()!= HAL_OK, DAQ_STATUS_HW_FLASH); //Checked using the same bin file with and without CRC
	REPORT_ON_ERROR(BSPUSBStart()			!= HAL_OK, DAQ_STATUS_HW_GENERAL);
	 
	return DAQCALL_RESULT_SUCCESS; 
}

DAQCALL_RESULT DAQUSBStart()
{
	USBD_HandleTypeDef *uh; 
	uh = BSPUSBInit(); 
	DAQInitState(uh);
}

DAQCALL_RESULT DACSet(float volts)
{
	int dav = (float)(1 << DACResolution) * volts / DACMaxVolt;
	if (BSPDACSet(dav) != HAL_OK)
		return DAQCALL_RESULT_CATASTROPHIC; 
	return DAQCALL_RESULT_SUCCESS; 
}




static void SystemClock_Config(void)
{
    RCC_ClkInitTypeDef RCC_ClkInitStruct;
    RCC_OscInitTypeDef RCC_OscInitStruct;

    __PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = (long)HSE_VALUE / 1000000L;
    RCC_OscInitStruct.PLL.PLLN = 336;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 7;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

		HAL_PWREx_ActivateOverDrive(); 

    RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK |
                                   RCC_CLOCKTYPE_HCLK |
                                   RCC_CLOCKTYPE_PCLK1 |
                                   RCC_CLOCKTYPE_PCLK2);

    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);	
}