///////////////////////////////////////////////////////////
//dac.h 
//constants definition for DAC 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DAC_H__
#define __DAC_H__

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include <stm32f4xx_hal_rcc.h>
#include <stm32f4xx_hal_rcc_ex.h>

/* Definition for DACx clock resources */
#define DACx                            DAC
#define DACx_CLK_ENABLE()               __DAC_CLK_ENABLE()
#define DACx_CHANNEL_GPIO_CLK_ENABLE()  __GPIOA_CLK_ENABLE()

#define DACx_FORCE_RESET()              __DAC_FORCE_RESET()
#define DACx_RELEASE_RESET()            __DAC_RELEASE_RESET()
     
/* Definition for DAC Channel Pin */
#define DACx_CHANNEL_PIN                GPIO_PIN_4
#define DACx_CHANNEL_GPIO_PORT          GPIOA 

/* Definition for ADCx's Channel */
#define DACx_CHANNEL                    DAC_CHANNEL_1

void HAL_DAC_MspInit(DAC_HandleTypeDef* hdac); 

#endif /* __DAC_H__ */
