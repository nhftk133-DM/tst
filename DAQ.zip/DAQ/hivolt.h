#ifndef __HIVOLT_H__
#define __HIVOLT_H__
#include <stm32f4xx_hal.h>
#include <stm32f4xx_hal_rcc.h>
/////////////////////////////////////////////////
// HV ports renamed - ref schematics 

#define GPIO_HV_PORT	GPIOK 
#define GPIO_SIPM_PORT	GPIOJ         //Define SiPM Enablbe/Disable pin intead HV2 (28/3/17)

#define GPIO_HV_PIN		GPIO_PIN_7
#define GPIO_SIPM_PIN	GPIO_PIN_11  //Define SiPM Enablbe/Disable pin intead HV2 (28/3/17)

#define POT_I2C_ADDRESS 0x58
#define POT_SIPM_I2C_ADDRESS 0x5C    //Define SiPM Digital Potentiometer adderss (28/3/17)




#endif