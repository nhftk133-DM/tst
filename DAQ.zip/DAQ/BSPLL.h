/////////////////////////////////////////////////////////////////
//BSPLL.h 
//Sytem constants definitions
//Also includes all the function declarations for all the SW submodules of the system


#ifndef __BSPLL_H__
#define __BSPLL_H__

#include "DAQTypes.h"
#include "stm32f4xx_hal.h"
#include <stm32f4xx_hal_rcc.h>

#include "i2c.h"
#include "pwm.h"
#include "dac.h"
#include "adc.h"
#include "wd.h"
#include "swtimer.h"
#include "max_spi.h"
#include "leds.h"
#include "hivolt.h" 
#include "extfifo.h"
#include "usbd_def.h" 
//#include "daq_fsm.h"

typedef struct DAQGPIO_
{
	GPIO_TypeDef *port; 
	uint16_t pin; 
} DAQGPIO; 

#define EEPROM_I2C_ADDRESS 0xA0
#define EEPROM_I2C_PAGESIZE 0x08
#define EEPROM_I2C_SIZE 256
#define EEPROM_I2C_ADDRESS_CHECK (EEPROM_I2C_SIZE-1)


#define DAQ_FIFO_WIDTH							FMC_NORSRAM_MEM_BUS_WIDTH_32
#define DAQ_FIFO_DMA_STREAM					DMA2_Stream0
#define DAQ_FIFO_DMA_CHANNEL				DMA_CHANNEL_0
#define DAQ_FIFO_DMA_IRQ						DMA2_Stream0_IRQn
#define DAQ_FIFO_DMA_STREAM_IRQHANDLER    DMA2_Stream0_IRQHandler

#define FIFO_BASE_ADDR              ((uint32_t)0x60000000)

#define DAQ_SDRAM_SIZE							8*4*1024*1024 //SDRAM is 8M DWORDS 
#define SDRAM_BASE_ADDR							((uint32_t)0xC0000000)

#define DACMaxVolt 5.0 
#define DACResolution  8 

#define POT_MAX_RES 50000



HAL_StatusTypeDef BSPDACInit(); 
HAL_StatusTypeDef BSPDACSet(int dav); 
HAL_StatusTypeDef BSPPWMInit(); 
HAL_StatusTypeDef BSPPWMSet(int freq, int pct); 
HAL_StatusTypeDef BSPCheckPMTCH10(int mn, int mx);
uint32_t BSPPWMEvents(); 
HAL_StatusTypeDef BSPPWMStop(); 
HAL_StatusTypeDef BSPHVInit(uint8_t i);
HAL_StatusTypeDef BSPHVEnable(uint8_t hv, uint8_t ena); 
HAL_StatusTypeDef BSPHVSet(uint8_t hv, uint8_t val); 
HAL_StatusTypeDef BSPEERead(uint8_t add, uint8_t *data, uint8_t *ndata); 
HAL_StatusTypeDef BSPEEWrite(uint8_t add, uint8_t *data, uint8_t *ndata);
HAL_StatusTypeDef BSPEECheck(); 
HAL_StatusTypeDef BSPGPIOInit(); 
HAL_StatusTypeDef BSPResetFifoAndCPLD(); 
HAL_StatusTypeDef BSPADCStartAcquisition(int start); 
HAL_StatusTypeDef BSPSetGPIOByNum(uint8_t num, uint8_t val);  
HAL_StatusTypeDef BSPExtIntInit();
HAL_StatusTypeDef BSPFromEWD(); 

//HAL_StatusTypeDef BSPVerCpuCpld(uint16_t CpuVer);
HAL_StatusTypeDef BSPVerCpu(char CpuVer1, char CpuVer2);   // New header function (5/4/17)

void BSPPollINTS();
void BSPWDDisable(); 
void BSPWDEnable(); 
void BSPWDKick();

void BSPI2CInit(); 
void BSPI2CDeInit(); 

USBD_HandleTypeDef* BSPUSBInit(); 
HAL_StatusTypeDef BSPUSBStart();  
 
#define REPORT_ON_ERROR(x,e) do { if (x) { DAQSetDebugStatus(DAQGetDebugStatus() | e);  } } while(0)

#endif
