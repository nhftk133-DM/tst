#include "daq_queue.h" 
#include "extfifo.h" 

//////////////////////////////////////////////////
//Resets the queue state
void DAQ_QUEUE_Init(DAQ_QUEUE_Handle qh)
{
	qh->rp = qh->wp = qh->sz = qh->full = 0; 
	qh->empty = 1;
	qh->cnt_empty = qh->cnf_full = 0;  
}

///////////////////////////////////////////////////////////////////
// returns a pointer to the next full buffer in queue
DAQUSBDATAHandle DAQ_QUEUE_GetDAQBuf(DAQ_QUEUE_Handle qh)
{
	if (!qh->empty)
		return qh->buf[qh->rp]; 
	else 
		return (DAQUSBDATAHandle)NULL; 
}

//////////////////////////////////////////////////////////
// Release current full buffer
// NB done with interrupt disable because of race 
// with USB interrupt
void DAQ_QUEUE_IncReadPtr(DAQ_QUEUE_Handle qh)
{
	__disable_irq();
	if (qh->empty) {
		__enable_irq();
		return; 	
	}
	qh->sz -= qh->buf[qh->rp]->blockInfo.dwSize;
	//qh->buf[qh->rp]->blockInfo.dwSize = 0; 
	if (++qh->rp == qh->nb)
		qh->rp = 0;
	qh->full = 0;
	qh->empty = (qh->rp == qh->wp);
	if (qh->empty)
		qh->cnt_empty++;
	__enable_irq();
}

///////////////////////////////////////////
//Reads data from external FIFO to next 
//avilable qeue buffer
//Uses DMA for speed - end of DMA is polled
int32_t DAQ_QUEUE_XferData(DAQ_QUEUE_Handle qh,  DAQDWORD nEvents, DAQDWORD eStatus, uint32_t dwbkCounter,  uint32_t size)
{
	uint32_t xfd = 0;
	uint32_t xfs = 0;
	DAQUSBDATAHandle hdb;
	 
	//qh->empty = 0;
	__disable_irq();
	if (qh->full)
	{
		__enable_irq();
		return xfd; 		
	}
	qh->empty = 0;
	hdb = qh->buf[qh->wp];
	if (++qh->wp == qh->nb)
		qh->wp =0;
	qh->full = (qh->wp == qh->rp); 
	xfs = size > qh->bs ? qh->bs : size;
	qh->sz += xfs;
	__enable_irq();
	 
	hdb->blockInfo.dwCounter = dwbkCounter; 
	if (BSPFMCStartMove(hdb->blockData , xfs) != HAL_OK) {			
		hdb->blockInfo.eDBStatus = eDAQ_BS_ERROR; 
		return -xfd;
	}
	BSPFMCEndMove();
	
	hdb->blockInfo.dwSize = xfs;
	hdb->blockInfo.eDBStatus = eStatus; 
	hdb->blockInfo.dwEvents = nEvents; //qh->sz << 16 | qh->wp << 8 | qh->rp; // 
	xfd += xfs;
	if (qh->full)
		qh->cnf_full++; 

	return xfd; 
}


///////////////////////////////////////////////////////////////////////
// read FIFO state - unused
uint32_t DAQ_QUEUE_GetMaxBufSize(DAQ_QUEUE_Handle qh) {return qh->bs; }
uint32_t DAQ_QUEUE_GetSize(DAQ_QUEUE_Handle qh) { return qh->sz; }
uint8_t DAQ_QUEUE_Full(DAQ_QUEUE_Handle qh) { return qh->full; }
uint8_t DAQ_QUEUE_Empty(DAQ_QUEUE_Handle qh) {return qh->empty; }

