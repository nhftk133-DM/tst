#include "BSPLL.h"
#include "swtimer.h"
//////////////////////////////////////////////////
// swtimer.c
// SW timers
// Those are drven by the SysTick interrupt - 10ms tick. 
// and are used to time long delays. Since thier state is polled 
// by the main loop, they are quite accurate

DAQSWTIMER s_timers[NSWTIMERS];

///////////////////////////////////////////////
// Deallocates and disables all the timer
void DAQTimersInit(void)
{
	int i;
	for(i=0; i<NSWTIMERS; i++)
		s_timers[i].mAllocated = 0; 
}

////////////////////////////////////////////////
// Checks if a specific timer rolled, and resets its mRolled flag
uint8_t DAQTimerRoll(uint8_t timer) 
{
	if (timer > NSWTIMERS || s_timers[timer].mAllocated == 0)
		return (uint8_t)(0); 
	uint8_t rld = s_timers[timer].mRolled;
	s_timers[timer].mRolled = 0;
	return rld; 
}
/////////////////////////////////////////////////////
// Disables a timer until DAQTimerStart is called upon it
DAQCALL_RESULT DAQTimerStop(uint8_t timer)
{
	if (timer > NSWTIMERS || s_timers[timer].mAllocated == 0)
		return DAQCALL_RESULT_BADPARAMS;
	s_timers[timer].mEnabled = 0; 
}
//////////////////////////////////////////////////////
//Enables and resets the timer
DAQCALL_RESULT DAQTimerStart(uint8_t timer)
{
	if (timer > NSWTIMERS || s_timers[timer].mAllocated == 0)
		return DAQCALL_RESULT_BADPARAMS;
	s_timers[timer].mRolled = 0;
	s_timers[timer].mCount = 0;
	s_timers[timer].mEnabled = 1;
	return DAQCALL_RESULT_SUCCESS; 
}

///////////////////////////////////////////////////
//Defines the timer parameters: its period and if it a one shot or periodic
DAQCALL_RESULT DAQTimerInit(uint8_t timer, uint32_t len, uint32_t periodic)
{
	if (timer > NSWTIMERS || s_timers[timer].mAllocated == 0)
		return DAQCALL_RESULT_BADPARAMS;
	s_timers[timer].mLen = len; 	 
	s_timers[timer].mPeriodic = periodic; 
	s_timers[timer].mRolled = 0;
	s_timers[timer].mCount = 0;
	s_timers[timer].mEnabled = 0; 
	return DAQCALL_RESULT_SUCCESS;
}
//////////////////////////////////////////
//Allocates a timer. For simplicity there is a fixed number of them
DAQSWTIMERHandle DAQTimerGetTimer(void)
{
	int i; 
	for(i=0; i<NSWTIMERS; i++)
		if (!s_timers[i].mAllocated) {
			s_timers[i].mAllocated = 1; 
			return i; 
		}
		return NOTIMER;
}
//////////////////////////////////////////
//Called by SysTick handler. 
//Loops over all the allocated timers and updates their state
void DAQTimersUpdate()
{
	DAQSWTIMER *tm; 
	int i; 
	for(i=0; i<NSWTIMERS; i++) {
		tm = &s_timers[i]; 
		if (tm->mAllocated) {
			if (tm->mEnabled) {
				tm->mCount++;
				if (tm->mCount == tm->mLen) {
//					if (i == 6)
//						tm->mRolled++;
					tm->mRolled++; 
					tm->mCount = 0; 
					if (!tm->mPeriodic)
						tm->mEnabled = 0; 
				}				 
			}
		}
	}
}
