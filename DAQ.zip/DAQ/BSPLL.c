#include "BSPLL.h"

#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_WinUSBComm.h" 

void DAQ_QUEUE_IRAM_GetMemory(uint32_t **mem, uint32_t* size); 

//////////////////////////////////////////////////////////
// Those handles are used by ST BSP functions to access 
// The on-chip peripherals
static DAC_HandleTypeDef    hDAC;
static I2C_HandleTypeDef hI2CHandle;
static USBD_HandleTypeDef s_USBD_Device;
static	TIM_HandleTypeDef  hPWMHandle;
static  TIM_HandleTypeDef  hPWMCounterHandle;
static	TIM_OC_InitTypeDef sPWMConfig;
static SRAM_HandleTypeDef hsram;
static DMA_HandleTypeDef  hDMAHandle; 
SDRAM_HandleTypeDef hsdram;

////////////////////////////////////////////

static uint8_t bDMAEnded = 0;  //external FIFO to SDRAM DMA transfer flag

static void I2Cx_Error(uint8_t Addr);
//////////////////////////////////////////////////////////
// Memory to memory DMA xfer functions 
static HAL_StatusTypeDef BSP_DMA_Init(DMA_HandleTypeDef* hDMAHandler); 
static void BSP_DMA_Complete(DMA_HandleTypeDef* hDMAHandler); 
static void BSP_DMA_Error(DMA_HandleTypeDef* hDMAHandler); 

//defines for SDRAM initializaion
#define SDRAM_MODEREG_BURST_LENGTH_1             ((uint16_t)0x0000)
#define SDRAM_MODEREG_BURST_LENGTH_2             ((uint16_t)0x0001)
#define SDRAM_MODEREG_BURST_LENGTH_4             ((uint16_t)0x0002)
#define SDRAM_MODEREG_BURST_LENGTH_8             ((uint16_t)0x0004)
#define SDRAM_MODEREG_BURST_TYPE_SEQUENTIAL      ((uint16_t)0x0000)
#define SDRAM_MODEREG_BURST_TYPE_INTERLEAVED     ((uint16_t)0x0008)
#define SDRAM_MODEREG_CAS_LATENCY_2              ((uint16_t)0x0020)
#define SDRAM_MODEREG_CAS_LATENCY_3              ((uint16_t)0x0030)
#define SDRAM_MODEREG_OPERATING_MODE_STANDARD    ((uint16_t)0x0000)
#define SDRAM_MODEREG_WRITEBURST_MODE_PROGRAMMED ((uint16_t)0x0000)
#define SDRAM_MODEREG_WRITEBURST_MODE_SINGLE     ((uint16_t)0x0200)
#define REFRESH_COUNT       ((uint32_t)0x0569)   /* SDRAM refresh counter (90MHz SD clock) */

////////////////////////////////////////////
// Initializes the external SDRAM
// Consult any SDRAM datasheet to understand the
// sequence
static void SDRAM_Initialization_Sequence(SDRAM_HandleTypeDef *hsdram, FMC_SDRAM_CommandTypeDef *Command)
{
  __IO uint32_t tmpmrd =0;
  /* Step 3:  Configure a clock configuration enable command */
  Command->CommandMode 			 = FMC_SDRAM_CMD_CLK_ENABLE;
  Command->CommandTarget 		 = FMC_SDRAM_CMD_TARGET_BANK1;
  Command->AutoRefreshNumber 	 = 1;
  Command->ModeRegisterDefinition = 0;

  /* Send the command */
  HAL_SDRAM_SendCommand(hsdram, Command, 0x1000);

  /* Step 4: Insert 100 ms delay */
  HAL_Delay(100);
    
  /* Step 5: Configure a PALL (precharge all) command */ 
  Command->CommandMode 			 = FMC_SDRAM_CMD_PALL;
  Command->CommandTarget 	     = FMC_SDRAM_CMD_TARGET_BANK1;
  Command->AutoRefreshNumber 	 = 1;
  Command->ModeRegisterDefinition = 0;

  /* Send the command */
  HAL_SDRAM_SendCommand(hsdram, Command, 0x1000);  
  
  /* Step 6 : Configure a Auto-Refresh command */ 
  Command->CommandMode 			 = FMC_SDRAM_CMD_AUTOREFRESH_MODE;
  Command->CommandTarget 		 = FMC_SDRAM_CMD_TARGET_BANK1;
  Command->AutoRefreshNumber 	 = 8;
  Command->ModeRegisterDefinition = 0;

  /* Send the command */
  HAL_SDRAM_SendCommand(hsdram, Command, 0x1000);
  
  /* Step 7: Program the external memory mode register */
  tmpmrd = (uint32_t)SDRAM_MODEREG_BURST_LENGTH_1          |
                     SDRAM_MODEREG_BURST_TYPE_SEQUENTIAL   |
                     SDRAM_MODEREG_CAS_LATENCY_3           |
                     SDRAM_MODEREG_OPERATING_MODE_STANDARD |
                     SDRAM_MODEREG_WRITEBURST_MODE_SINGLE;
  
  Command->CommandMode = FMC_SDRAM_CMD_LOAD_MODE;
  Command->CommandTarget 		 = FMC_SDRAM_CMD_TARGET_BANK1;
  Command->AutoRefreshNumber 	 = 1;
  Command->ModeRegisterDefinition = tmpmrd;

  /* Send the command */
  HAL_SDRAM_SendCommand(hsdram, Command, 0x1000);
  
  /* Step 8: Set the refresh rate counter */
  /* (15.62 us x Freq) - 20 */
  /* Set the device refresh counter */
  hsdram->Instance->SDRTR |= ((uint32_t)((1292)<< 1));
  HAL_SDRAM_ProgramRefreshRate(hsdram, REFRESH_COUNT); 
}

////////////////////////////////////////////////////
// Init the CPU SDRAM controller
HAL_StatusTypeDef BSPInitSDRAM(void )
{
	FMC_SDRAM_TimingTypeDef SDRAM_Timing;
	FMC_SDRAM_CommandTypeDef command;
	uint32_t *pBASEDSRAM = (uint32_t*)((void *)SDRAM_BASE_ADDR); 
	hsdram.Instance = FMC_SDRAM_DEVICE;
	uint32_t i = 0; 
  
  /* Timing configuration for 84 MHz of SD clock frequency (168MHz/2) */
  /* TMRD: 2 Clock cycles */
  SDRAM_Timing.LoadToActiveDelay    = 2;
  /* TXSR: min=70ns (6x11.90ns) */
  SDRAM_Timing.ExitSelfRefreshDelay = 6;
  /* TRAS: min=42ns (4x11.90ns) max=120k (ns) */
  SDRAM_Timing.SelfRefreshTime      = 4;
  /* TRC:  min=63 (6x11.90ns) */        
  SDRAM_Timing.RowCycleDelay        = 6;
  /* TWR:  2 Clock cycles */
  SDRAM_Timing.WriteRecoveryTime    = 2;
  /* TRP:  15ns => 2x11.90ns */
  SDRAM_Timing.RPDelay              = 2;
  /* TRCD: 15ns => 2x11.90ns */
  SDRAM_Timing.RCDDelay             = 2;

  hsdram.Init.SDBank             = FMC_SDRAM_BANK1;
	hsdram.Init.ColumnBitsNumber	 = FMC_SDRAM_COLUMN_BITS_NUM_9;//FMC_SDRAM_COLUMN_BITS_NUM_8;
	hsdram.Init.RowBitsNumber			 = FMC_SDRAM_ROW_BITS_NUM_12;
  hsdram.Init.MemoryDataWidth    = FMC_SDRAM_MEM_BUS_WIDTH_32;
  hsdram.Init.InternalBankNumber = FMC_SDRAM_INTERN_BANKS_NUM_4;
  hsdram.Init.CASLatency         = FMC_SDRAM_CAS_LATENCY_3;
  hsdram.Init.WriteProtection    = FMC_SDRAM_WRITE_PROTECTION_DISABLE;
  hsdram.Init.SDClockPeriod      = FMC_SDRAM_CLOCK_PERIOD_2;
  hsdram.Init.ReadBurst          = FMC_SDRAM_RBURST_ENABLE;
  hsdram.Init.ReadPipeDelay      = FMC_SDRAM_RPIPE_DELAY_0;

  /* Initialize the SDRAM controller */
  
  if(HAL_SDRAM_Init(&hsdram, &SDRAM_Timing) != HAL_OK)
  {
    // Initialization Error 
		return HAL_ERROR; 
  }
  
  // Program the SDRAM external device
  SDRAM_Initialization_Sequence(&hsdram, &command);   

  for(i=0; i < DAQ_SDRAM_SIZE/ 4; i++)
  {
	*(pBASEDSRAM+i) = i*1027; 
  }

  for (i=0; i < DAQ_SDRAM_SIZE/ 4; i++)
  {
    if (i*1027 != *(pBASEDSRAM+i))
		return HAL_ERROR; 
  }
  return HAL_OK;
}
////////////////////////////////////////////////////
// SDRAM pinout 
void SystemInit_ExtMemCtl(void)
{
#define DATA_IN_ExtSDRAM

#if defined (DATA_IN_ExtSDRAM)
  register uint32_t tmpreg = 0, timeout = 0xFFFF;
  register uint32_t index;

  /* Enable GPIOC, GPIOD, GPIOE, GPIOF, GPIOG, GPIOH and GPIOI interface 
      clock */
  RCC->AHB1ENR |= 0x000001F8;
  
  /* Connect PDx pins to FMC Alternate function */
  GPIOD->AFR[0]  = 0x000000CC;
  GPIOD->AFR[1]  = 0xCC000CCC;
  /* Configure PDx pins in Alternate function mode */  
  GPIOD->MODER   = 0xA02A000A;
  /* Configure PDx pins speed to 50 MHz */  
  GPIOD->OSPEEDR = 0xF03F000F;
  /* Configure PDx pins Output type to push-pull */  
  GPIOD->OTYPER  = 0x00000000;
  /* No pull-up, pull-down for PDx pins */ 
  GPIOD->PUPDR   = 0x00000000;

  /* Connect PEx pins to FMC Alternate function */
  GPIOE->AFR[0]  = 0xC00000CC;
  GPIOE->AFR[1]  = 0xCCCCCCCC;
  /* Configure PEx pins in Alternate function mode */ 
  GPIOE->MODER   = 0xAAAA800A;
  /* Configure PEx pins speed to 50 MHz */ 
  GPIOE->OSPEEDR = 0xFFFFC00F;
  /* Configure PEx pins Output type to push-pull */  
  GPIOE->OTYPER  = 0x00000000;
  /* No pull-up, pull-down for PEx pins */ 
  GPIOE->PUPDR   = 0x00000000;

  /* Connect PFx pins to FMC Alternate function */
  GPIOF->AFR[0]  = 0xCCCCCCCC;
  GPIOF->AFR[1]  = 0xCCCCCCCC;
  /* Configure PFx pins in Alternate function mode */   
  GPIOF->MODER   = 0xAA800AAA;
  /* Configure PFx pins speed to 50 MHz */ 
  GPIOF->OSPEEDR = 0xFFC00FFF;
  /* Configure PFx pins Output type to push-pull */  
  GPIOF->OTYPER  = 0x00000000;
  /* No pull-up, pull-down for PFx pins */ 
  GPIOF->PUPDR   = 0x00000000;

  /* Connect PGx pins to FMC Alternate function */
  GPIOG->AFR[0]  = 0xCCCCCCCC;
  GPIOG->AFR[1]  = 0xCCCCCCCC;
  /* Configure PGx pins in Alternate function mode */ 
  GPIOG->MODER   = 0xAAAAAAAA;
  /* Configure PGx pins speed to 50 MHz */ 
  GPIOG->OSPEEDR = 0xFFFFFFFF;
  /* Configure PGx pins Output type to push-pull */  
  GPIOG->OTYPER  = 0x00000000;
  /* No pull-up, pull-down for PGx pins */ 
  GPIOG->PUPDR   = 0x00000000;
  
  /* Connect PHx pins to FMC Alternate function */
  GPIOH->AFR[0]  = 0x00C0CC00;
  GPIOH->AFR[1]  = 0xCCCCCCCC;
  /* Configure PHx pins in Alternate function mode */ 
  GPIOH->MODER   = 0xAAAA08A0;
  /* Configure PHx pins speed to 50 MHz */ 
  GPIOH->OSPEEDR = 0xFFFF0CF0;
  /* Configure PHx pins Output type to push-pull */  
  GPIOH->OTYPER  = 0x00000000;
  /* No pull-up, pull-down for PHx pins */ 
  GPIOH->PUPDR   = 0x00000000;
  
  /* Connect PIx pins to FMC Alternate function */
  GPIOI->AFR[0]  = 0xCCCCCCCC;
  GPIOI->AFR[1]  = 0x00000CC0;
  /* Configure PIx pins in Alternate function mode */ 
  GPIOI->MODER   = 0x0028AAAA;
  /* Configure PIx pins speed to 50 MHz */ 
  GPIOI->OSPEEDR = 0x003CFFFF;
  /* Configure PIx pins Output type to push-pull */  
  GPIOI->OTYPER  = 0x00000000;
  /* No pull-up, pull-down for PIx pins */ 
  GPIOI->PUPDR   = 0x00000000;
  
/*-- FMC Configuration ------------------------------------------------------*/
  /* Enable the FMC interface clock */
  RCC->AHB3ENR |= 0x00000001;
  
  /* Configure and enable SDRAM bank1 */
  FMC_Bank5_6->SDCR[0] = 0x00001AE4;
  FMC_Bank5_6->SDTR[0] = 0x00000001;      
  
  /* SDRAM initialization sequence */
  /* Clock enable command */
  FMC_Bank5_6->SDCMR = 0x00000011; 
  tmpreg = FMC_Bank5_6->SDSR & 0x00000020; 
  while((tmpreg != 0) && (timeout-- > 0))
  {
    tmpreg = FMC_Bank5_6->SDSR & 0x00000020; 
  }

  /* Delay */
  for (index = 0; index<1000; index++);
  
  /* PALL command */
  FMC_Bank5_6->SDCMR = 0x00000012;           
  timeout = 0xFFFF;
  while((tmpreg != 0) && (timeout-- > 0))
  {
    tmpreg = FMC_Bank5_6->SDSR & 0x00000020; 
  }
  
  /* Auto refresh command */
  FMC_Bank5_6->SDCMR = 0x00000073;
  timeout = 0xFFFF;
  while((tmpreg != 0) && (timeout-- > 0))
  {
    tmpreg = FMC_Bank5_6->SDSR & 0x00000020; 
  }
 
  /* MRD register program */
  FMC_Bank5_6->SDCMR = 0x00046014;
  timeout = 0xFFFF;
  while((tmpreg != 0) && (timeout-- > 0))
  {
    tmpreg = FMC_Bank5_6->SDSR & 0x00000020; 
  } 
  
  /* Set refresh count */
  tmpreg = FMC_Bank5_6->SDRTR;
  FMC_Bank5_6->SDRTR = (tmpreg | (0x0000027C<<1));
  
  /* Disable write protection */
  tmpreg = FMC_Bank5_6->SDCR[0]; 
  FMC_Bank5_6->SDCR[0] = (tmpreg & 0xFFFFFDFF);
#endif /* DATA_IN_ExtSDRAM */

}
////////////////////////////////////////////
// CPU DAC init 
HAL_StatusTypeDef BSPDACInit() 
{
	GPIO_InitTypeDef     GPIO_InitStruct;
	DAC_ChannelConfTypeDef sConfig;

	hDAC.Instance = DACx;
	HAL_DAC_Init(&hDAC); 
	sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
	sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;  
	HAL_DAC_ConfigChannel(&hDAC, &sConfig, DACx_CHANNEL); 
}
/////////////////////////////////
// Set DAC value. Need to restore the IO analog function (muxed with SPI 2nd chip select)
HAL_StatusTypeDef BSPDACSet(int dav)
{	
	GPIO_InitTypeDef GPIO_InitStruct; 

	GPIO_InitStruct.Pin = DACx_CHANNEL_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(DACx_CHANNEL_GPIO_PORT, &GPIO_InitStruct);

	if (HAL_DAC_SetValue(&hDAC, DACx_CHANNEL, DAC_ALIGN_8B_R, dav) != HAL_OK)
		return HAL_ERROR; 
	if (HAL_DAC_Start(&hDAC, DACx_CHANNEL) != HAL_OK)
		return HAL_ERROR; 
	return HAL_OK; 

}

////////////////////////////////////////////////
// Unused
HAL_StatusTypeDef BSPExtIntInit()
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	__GPIOC_CLK_ENABLE(); 
	GPIO_InitStructure.Mode = GPIO_MODE_INPUT;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  GPIO_InitStructure.Pin = GPIO_PIN_1| GPIO_PIN_2|GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);
	HAL_NVIC_SetPriority(EXTI3_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);
	HAL_NVIC_SetPriority(EXTI4_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);
	HAL_NVIC_SetPriority(EXTI9_5_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
  return HAL_OK; 
}
/////////////////////////////////////////////////////////
//External inputs resynchronization
uint16_t intpins[] = {GPIO_PIN_1,GPIO_PIN_2, GPIO_PIN_3 , GPIO_PIN_4 , GPIO_PIN_5};
DAQ_FSM_INPUT intins[] = { eDAQFIFOFF, eDAQFIFOEF, eDAQFIFOHF, eDAQFIFOEF, eDAQFIFOAF}; 

void BSPPollINTS()
{
	int i; 
	for(i=0; i<5; i++)
	{
		if (HAL_GPIO_ReadPin(GPIOC, intpins[i]) == GPIO_PIN_RESET)
			DAQInputSet(intins[i]); 
		else 
			DAQInputClr(intins[i]);
	}
}
///////////////////////////////////////////////////////////////

void DAQ_FIFO_DMA_STREAM_IRQHANDLER(void)
{
    /* Check the interrupt and clear flag */
    HAL_DMA_IRQHandler(&hDMAHandle);  
}
////////////////////////////////////////////////////////
// Called after end of ext FIFO to SDRAM memory transfer
void BSP_DMA_Complete(DMA_HandleTypeDef* hDMAHandler)
{
	static int i = 0; 
	i++; 
	bDMAEnded = 1; 
}



void BSP_DMA_Error(DMA_HandleTypeDef* hDMAHandler)
{
}

////////////////////////////////////////////////////////////
// INit ext memory DMA 
static HAL_StatusTypeDef BSP_DMA_Init(DMA_HandleTypeDef* hDMAHandle)
{   
  /*## -1- Enable DMA2 clock #################################################*/
	memset(hDMAHandle, 0, sizeof(DMA_HandleTypeDef));
  __DMA2_CLK_ENABLE();

  /*##-2- Select the DMA functional Parameters ###############################*/
  hDMAHandle->Init.Channel = DAQ_FIFO_DMA_CHANNEL;                     /* DMA_CHANNEL_0                    */                     
  hDMAHandle->Init.Direction = DMA_MEMORY_TO_MEMORY;          /* M2M transfer mode                */           
  hDMAHandle->Init.PeriphInc = DMA_PINC_ENABLE;               /* Peripheral increment mode Enable */                 
  hDMAHandle->Init.MemInc = DMA_MINC_ENABLE;                  /* Memory increment mode Enable     */                   
  hDMAHandle->Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD; /* Peripheral data alignment : Word */    
  hDMAHandle->Init.MemDataAlignment = DMA_MDATAALIGN_WORD;    /* memory data alignment : Word     */     
  hDMAHandle->Init.Mode = DMA_NORMAL;                         /* Normal DMA mode                  */  
  hDMAHandle->Init.Priority = DMA_PRIORITY_VERY_HIGH;              /* priority level : high            */  
  hDMAHandle->Init.FIFOMode = DMA_FIFOMODE_ENABLE;            /* FIFO mode enabled                */        
  hDMAHandle->Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;  
  hDMAHandle->Init.MemBurst = DMA_MBURST_INC4;                /* Memory burst                     */  
  hDMAHandle->Init.PeriphBurst = DMA_PBURST_INC4;             /* Peripheral burst                 */
  
  /*##-3- Select the DMA instance to be used for the transfer : DMA2_Stream0 #*/
  hDMAHandle->Instance = DAQ_FIFO_DMA_STREAM;

  /*##-4- Select Callbacks functions called after Transfer complete and Transfer error */
  hDMAHandle->XferCpltCallback  = BSP_DMA_Complete;
  hDMAHandle->XferErrorCallback = BSP_DMA_Error;
  
  /*##-5- Initialize the DMA stream ##########################################*/
  if(HAL_DMA_Init(hDMAHandle) != HAL_OK)
  {
    /* Initialization Error */
		return HAL_ERROR;
  }
  
  /*##-6- Configure NVIC for DMA transfer complete/error interrupts ##########*/
  HAL_NVIC_SetPriority(DAQ_FIFO_DMA_IRQ, 0, 0);
  HAL_NVIC_EnableIRQ(DAQ_FIFO_DMA_IRQ);

}

///////////////////////////////////////////////////////
// External memory interface to FIFO initialization
HAL_StatusTypeDef BSPFMCInit()
{
	FMC_NORSRAM_TimingTypeDef SRAM_Timing;
	uint32_t *sramStart; 
	uint32_t sramSize; 
	uint32_t i; 

  hsram.Instance  = FMC_NORSRAM_DEVICE;
  hsram.Extended  = 0; //FMC_NORSRAM_EXTENDED_DEVICE;
	
  SRAM_Timing.AddressSetupTime       = 0;
  SRAM_Timing.AddressHoldTime        = 2;
  SRAM_Timing.DataSetupTime          = 2;
  SRAM_Timing.BusTurnAroundDuration  = 0;
  SRAM_Timing.CLKDivision            = 0;
  SRAM_Timing.DataLatency            = 0;
  SRAM_Timing.AccessMode             = FMC_ACCESS_MODE_A;
  
  hsram.Init.NSBank             = FMC_NORSRAM_BANK1;
  hsram.Init.DataAddressMux     = FMC_DATA_ADDRESS_MUX_DISABLE;
  hsram.Init.MemoryType         = FMC_MEMORY_TYPE_SRAM; //FMC_MEMORY_TYPE_PSRAM; //FMC_MEMORY_TYPE_SRAM;
  hsram.Init.MemoryDataWidth    = FMC_NORSRAM_MEM_BUS_WIDTH_32;
  hsram.Init.BurstAccessMode    = FMC_BURST_ACCESS_MODE_DISABLE; //FMC_BURST_ACCESS_MODE_ENABLE;//FMC_BURST_ACCESS_MODE_DISABLE;
  hsram.Init.WaitSignalPolarity = FMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram.Init.WrapMode           = FMC_WRAP_MODE_DISABLE;
  hsram.Init.WaitSignalActive   = FMC_WAIT_TIMING_BEFORE_WS;
  hsram.Init.WriteOperation     = FMC_WRITE_OPERATION_DISABLE;// FMC_WRITE_OPERATION_ENABLE;
  hsram.Init.WaitSignal         = FMC_WAIT_SIGNAL_DISABLE;
  hsram.Init.ExtendedMode       = 0; //FMC_EXTENDED_MODE_ENABLE;
  hsram.Init.AsynchronousWait   = FMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram.Init.WriteBurst         = FMC_WRITE_BURST_DISABLE;
  hsram.Init.ContinuousClock    = FMC_CONTINUOUS_CLOCK_SYNC_ASYNC;
	
  if (HAL_SRAM_Init(&hsram, &SRAM_Timing, &SRAM_Timing) != HAL_OK)
  {
    /* Initialization Error */
		return HAL_ERROR; 
  }
	 
//	SystemInit_ExtMemCtl(); 
	BSP_DMA_Init(&hDMAHandle);
	////////////////////////////////////////////////////////////////
	// Internal memory buffer test
	DAQ_QUEUE_IRAM_GetMemory(&sramStart, &sramSize); //takes internal memory buffer start and size
	for (i=0; i<sramSize; i++) //writes a pseudo - random pattern 
	{ 
		*sramStart++ = i * 67; 
	}

	DAQ_QUEUE_IRAM_GetMemory(&sramStart, &sramSize); 
	for(i=0; i<sramSize; i++)  //check same pattern readback
	{		
		if (*sramStart++ != i*67)
			return HAL_ERROR; 
	}
	return HAL_OK; 
}

HAL_StatusTypeDef BSPFMCStartMove(uint8_t *dest, uint32_t sz)
{
  /*##-7- Start the DMA transfer using the interrupt mode ####################*/
  /* Configure the source, destination and buffer size DMA fields and Start DMA Stream transfer */
  /* Enable All the DMA interrupts */
	bDMAEnded = 0; 

  if(HAL_DMA_Start_IT(&hDMAHandle, FIFO_BASE_ADDR, (uint32_t)dest, sz / 4) != HAL_OK)    
  {
  //  /* Transfer error */
		return HAL_ERROR;   
  }           
	return HAL_OK;
}
//////////////////////////////////////////////////////
// poll for DMA end 
HAL_StatusTypeDef BSPFMCEndMove()
{
	while(!bDMAEnded); 
	return HAL_OK; 
}

/////////////////////////////////////////////
// check EEPROM by writing 0x73 to its last byte and read back 
HAL_StatusTypeDef BSPEECheck() 
{
	uint8_t d = 0x73; 
	uint8_t t; 
	uint8_t n = 1; 
	if (BSPEEWrite(EEPROM_I2C_ADDRESS_CHECK, &d, &n) == HAL_OK) {
		n = 1; 
		HAL_Delay(200);  //Add delay to avoid EEPROM Error (28/3/17)
		if (BSPEERead(EEPROM_I2C_ADDRESS_CHECK,&t, &n) == HAL_OK) {
			if (d == t)
				return HAL_OK; 
		}
	}
	return HAL_ERROR; 
}
////////////////////////////////////////////
// reads the I2C eeprom
// from star address, to buffer data. ndata holds the number of bytes to read 
// and returns the number of bytes effectively read 
HAL_StatusTypeDef BSPEERead(uint8_t add, uint8_t *data, uint8_t *ndata)
{
	HAL_StatusTypeDef ret;
	int n = 0; 
	if (*ndata == 0) 
		return HAL_ERROR; 
	if (data == NULL)
		return HAL_ERROR;
   for(n=0; n<*ndata; n++) {

	ret = HAL_I2C_Master_Transmit(&hI2CHandle, EEPROM_I2C_ADDRESS, &add, 1, 100);
	if (ret != HAL_OK)
		goto end; 
	ret = HAL_I2C_Master_Receive(&hI2CHandle, EEPROM_I2C_ADDRESS, data++, 1, 100);
	if (ret != HAL_OK)
		goto end; 

	add++; 
	}
end:
	*ndata = n; 
	return ret; 	 	
}
////////////////////////////////////////////////////////
// as before - for write
HAL_StatusTypeDef BSPEEWrite(uint8_t add, uint8_t *data, uint8_t *ndata)
{
	HAL_StatusTypeDef ret; 
	uint8_t dat[2]; 
	if (*ndata == 0) 
		return HAL_ERROR; 
	if (data == NULL)
		return HAL_ERROR;
	int n = 0; 
	int errcnt; 
	while (n < *ndata)
	{
		errcnt = 0; 
		dat[0] = add++; dat[1] = *data++; 
		do 
		{			
			ret = HAL_I2C_IsDeviceReady(&hI2CHandle, EEPROM_I2C_ADDRESS, 1, 100); 
			if (ret != HAL_OK)
			{
				errcnt++;
				if (errcnt > 20)
				{

					I2Cx_Error(EEPROM_I2C_ADDRESS);
					*ndata = n;
					return ret;
				}
				continue;
			}
				
			ret = HAL_I2C_Master_Transmit(&hI2CHandle, EEPROM_I2C_ADDRESS, dat, 2, 1000); 
			if (ret != HAL_OK) 
			{
				errcnt++; 				
				if (errcnt > 20) { 
					I2Cx_Error(EEPROM_I2C_ADDRESS); 
					*ndata = n; 
					return ret; 
				}
			}
		} while (ret != HAL_OK); 
		n++;
	}
	*ndata = n; 
	return HAL_OK; 
}

///////////////////////////////////////////
// Inits and tests the hv subsystem
HAL_StatusTypeDef BSPHVInit(uint8_t i)
{
	if (i > 1)
		return HAL_ERROR;
	 
	uint16_t pin = (i == 0) ? GPIO_HV_PIN : GPIO_SIPM_PIN;   //Change GPIO_HV1_PIN (HV2) to SiPM HV (28/3/17)

	GPIO_InitTypeDef GPIO_InitStructure;
	
	if (i == 0)    // Add "if" condition to init HV1 or SiPM 
	{
		__GPIOK_CLK_ENABLE(); 
		GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
		GPIO_InitStructure.Pull = GPIO_NOPULL;
		GPIO_InitStructure.Pin = pin;
		HAL_GPIO_Init(GPIO_HV_PORT, &GPIO_InitStructure);
		HAL_GPIO_WritePin(GPIO_HV_PORT, pin, GPIO_PIN_RESET);
	}
	else
	{
		__GPIOJ_CLK_ENABLE(); 
		GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
		GPIO_InitStructure.Pull = GPIO_NOPULL;
		GPIO_InitStructure.Pin = pin;
		HAL_GPIO_Init(GPIO_SIPM_PORT, &GPIO_InitStructure);         //Change to SiPM HV (28/3/17)
		HAL_GPIO_WritePin(GPIO_SIPM_PORT, pin, GPIO_PIN_RESET);     //Change to SiPM HV (28/3/17)
	}
	BSPHVEnable(i, 0);
	BSPHVSet(i, 0);

	uint16_t v;
	int j;
	uint32_t t; uint16_t p;
	
	if (i == 0)   // Add "if" condition to init HV1 or SiPM 
	{
		uint32_t pot[] = { 15000, 30000, 40000 };  //681 881V, 1033V    -- D.P 76.8, 153.6, 204.8
		uint32_t adc[] = { 1365, 1796, 2133 };     //New ADC value after HV resulotion change to 530 - 1200 (28/3/17)
		
		for (j = 0; j < sizeof(pot) / sizeof(uint32_t); j++) 
		{
			p =  256 * pot[j] / POT_MAX_RES; 
			BSPHVSet(i, p); 
			BSPHVEnable(i, 1);
			HAL_Delay(500); 
			BSPADCRead(i, &v); 
			t = 2500 * v / 4096; 
			BSPHVSet(i, 0); 
			BSPHVEnable(i, 0);
			if (((95 * adc[j] / 100) < t) && (t < (105 * adc[j] / 100))) {
				continue; 
			}
			else {
				return HAL_ERROR; 
			}
		}
		return HAL_OK;
	}
	else
	{
		uint32_t pot[] = { 78689, 27604, 14919 };    //-15.0V, -25.0V, -30.0V
		uint32_t adc[] = { 635, 1085, 1305 };       
		
		for (j = 0; j < sizeof(pot) / sizeof(uint32_t); j++) 
		{
			p =  256 * pot[j] / 100000; 
			BSPHVSet(i, p); 
			BSPHVEnable(i, 1);
			HAL_Delay(500); 
			BSPADCRead(2, &v); //Read SiPM ADC
			t = 2500 * v / 4096; 
			BSPHVSet(i, 0); 
			BSPHVEnable(i, 0);
			if (((95 * adc[j] / 100) < t) && (t < (105 * adc[j] / 100))) {
				continue; 
			}
			else {
				return HAL_ERROR; 
			}
		}
		return HAL_OK;
	}
}
/////////////////////////////////////////////////////////////
// sets HV channel hv to value val. val is a normalized value from host
HAL_StatusTypeDef BSPHVSet(uint8_t hv, uint8_t val)
{
	if (hv > 1)
		return HAL_ERROR;
	uint8_t pck[2]; 
	if (hv == 0)        // Add "if" condition to set D.P HV1 or SiPM 
	{
		pck[0] = 0 << 7; 
		pck[1] = val; 
		if (HAL_I2C_Master_Transmit(&hI2CHandle, POT_I2C_ADDRESS, pck, 2, 100) != HAL_OK) 
		{
			I2Cx_Error(POT_I2C_ADDRESS); 
			return HAL_ERROR; 
		}	
	}
	else
	{
		pck[0] = 1 << 7; 
		pck[1] = val; 
		if (HAL_I2C_Master_Transmit(&hI2CHandle, POT_SIPM_I2C_ADDRESS, pck, 2, 100) != HAL_OK) //Change HV1 D.P (HV2) to SiPM D.P (28/3/17)
		{
			I2Cx_Error(POT_SIPM_I2C_ADDRESS); 
			return HAL_ERROR; 
		}
	}
	
	return HAL_OK; 
}

/////////////////////////////////////////////////////////////////////
// sets enable bit for hv 
HAL_StatusTypeDef BSPHVEnable(uint8_t hv, uint8_t ena)
{
	uint16_t pin; 
	if (hv > 1)
		return HAL_ERROR;
	if (ena > 1)
		return HAL_ERROR; 
	
	if (hv == 0)   //Add "if" condition to En/Dis HV1 or SiPM
	{
		pin = GPIO_HV_PIN;
		HAL_GPIO_WritePin(GPIO_HV_PORT, pin, ena == 1 ? GPIO_PIN_SET : GPIO_PIN_RESET); 
		return HAL_OK;
	}
	else       //Enable or Disable SIPM HV
	{
		pin = GPIO_SIPM_PIN;   //Change HV1 En/Dis (HV2) to SiPM En/Dis (28/3/17)
		HAL_GPIO_WritePin(GPIO_SIPM_PORT, pin, ena == 1 ? GPIO_PIN_SET : GPIO_PIN_RESET); 
		return HAL_OK;
	}
}
///////////////////////////////////////////////
// Iits CPU PWM 
HAL_StatusTypeDef BSPPWMInit()
{
	//uint32_t uwPrescalerValue = ((SystemCoreClock /2) / 18000000) - 1;
	hPWMHandle.Instance = PWM_TIMER; 
	hPWMHandle.Init.Prescaler = 0; //uwPrescalerValue;
	hPWMHandle.Init.ClockDivision = 0;
	hPWMHandle.Init.Period        = 100;
	hPWMHandle.Init.CounterMode   = TIM_COUNTERMODE_UP;
	sPWMConfig.OCMode     = TIM_OCMODE_PWM1;
	sPWMConfig.OCPolarity = TIM_OCPOLARITY_HIGH;
	sPWMConfig.OCFastMode = TIM_OCFAST_DISABLE;
	sPWMConfig.Pulse = 20; 
	HAL_TIM_PWM_Init(&hPWMHandle); 
	HAL_TIM_PWM_ConfigChannel(&hPWMHandle, &sPWMConfig, TIM_CHANNEL_1); 


//	HAL_TIM_PWM_Start(&hPWMHandle, TIM_CHANNEL_1); 
	return HAL_OK;
}

//////////////////////////////////////////////////////
// Tests CH10. The mn and mx are the limits between each 
// measurement must reside. See main loop 
uint16_t data[DAQ_STATE_FIFO_HF_SIZE /2];
HAL_StatusTypeDef BSPCheckPMTCH10(int mn, int mx)
{
	 
	uint16_t oc;
	uint16_t nc = 16; 
	REPORT_ON_ERROR(BSPFMCStartMove((uint8_t*)data, DAQ_STATE_FIFO_HF_SIZE)!= HAL_OK, DAQ_STATUS_HW_CH10);	
	BSPFMCEndMove();
	for(oc = 13+10*nc; oc < DAQ_STATE_FIFO_HF_SIZE / 2; oc+=nc)
	{
		if (!(mn < data[oc] && data[oc] < mx)) {
			REPORT_ON_ERROR(1, DAQ_STATUS_HW_CH10); 
			return HAL_ERROR;
		}
	}
	return HAL_OK; 
}
/////////////////////////////////////////////
// unused
HAL_StatusTypeDef BSPFromEWD()
{
	return HAL_OK; 
	uint32_t *rcc;
	uint32_t c = (PERIPH_BASE + 0x00020000 + RCC_CSR_OFFSET);
	SCB->HFSR; 

	rcc = (uint32_t*)(c);
	rcc += RCC_CSR_OFFSET;
	rcc += 0x74 / 4; 
	if (*rcc & RCC_CSR_PADRSTF)
		return HAL_OK; 
	else 
		return HAL_ERROR; 	
}
///////////////////////////////////
// unused
uint32_t BSPPWMEvents() 
{
	return __HAL_TIM_GetCounter(&hPWMCounterHandle);  
}

/////////////////////////////////////////////////
// sets PWM freq and duty cycle
HAL_StatusTypeDef BSPPWMSet(int freq, int pct)
{
	TIM_SlaveConfigTypeDef   sSlaveConfig;
	TIM_MasterConfigTypeDef   sMasterConfig;

	HAL_TIM_PWM_Stop(&hPWMHandle, TIM_CHANNEL_1);
	hPWMHandle.Init.Period = (SystemCoreClock /2) / (freq * 1000); 	 
//	hPWMHandle.Init.Prescaler = ((SystemCoreClock /2) / rfr) - 1;
	sPWMConfig.Pulse = pct * hPWMHandle.Init.Period / 100; 
	HAL_TIM_PWM_Init(&hPWMHandle); 
	HAL_TIM_PWM_ConfigChannel(&hPWMHandle, &sPWMConfig, TIM_CHANNEL_1);
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_ENABLE;
	sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_ENABLE;
	if( HAL_TIMEx_MasterConfigSynchronization(&hPWMHandle,&sMasterConfig) != HAL_OK)
		return HAL_ERROR; 
	hPWMCounterHandle.Instance = PWM_COUNTER; 	
	hPWMCounterHandle.Init.Period            = 0xFFFFFFFF-1;
	hPWMCounterHandle.Init.Prescaler         = (SystemCoreClock /8) / (freq * 1000);
	hPWMCounterHandle.Init.ClockDivision     = 0;
	hPWMCounterHandle.Init.CounterMode       = TIM_COUNTERMODE_UP;
	hPWMCounterHandle.Init.RepetitionCounter = 0;
	PWM_COUNTER_CLK_ENABLE(); 
	if(HAL_TIM_Base_Init(&hPWMCounterHandle) != HAL_OK)
	{
		return HAL_ERROR;
	}

	sSlaveConfig.SlaveMode     = TIM_SLAVEMODE_GATED;
	sSlaveConfig.InputTrigger  = TIM_TS_ITR0;
	
	if(HAL_TIM_SlaveConfigSynchronization(&hPWMCounterHandle, &sSlaveConfig) != HAL_OK)
	{
		return HAL_ERROR;
	}

	HAL_TIM_PWM_Start(&hPWMHandle, TIM_CHANNEL_1); 
	HAL_TIM_Base_Start(&hPWMCounterHandle); 
	return  HAL_OK;
}

HAL_StatusTypeDef BSPPWMStop()
{
	HAL_TIM_PWM_Stop(&hPWMHandle, TIM_CHANNEL_1);
}

//////////////////////////////////////////////////////////////
// Command for cpld to initiate the acq cycle
HAL_StatusTypeDef BSPADCStartAcquisition(int start)
{
	HAL_GPIO_WritePin(CPLD_SOC_PORT, CPLD_SOC_PIN,			start ? GPIO_PIN_SET : GPIO_PIN_RESET); 
	return HAL_OK; 
}

/////////////////////////////////////////////////
// enables external WD
// Ref schematic and ext WD datasheet 
// for details
void BSPWDEnable()
{
	GPIO_InitTypeDef wdp; 
	__GPIOG_CLK_ENABLE();
	wdp.Mode = GPIO_MODE_OUTPUT_PP;
	wdp.Speed = GPIO_SPEED_HIGH;
	wdp.Pull = GPIO_PULLUP | GPIO_PULLDOWN;
	wdp.Pin = WD_PIN;
	HAL_GPIO_Init(WD_PORT, &wdp); 
}

/////////////////////////////////////////////////
// disables external WD
void BSPWDDisable()
{
	GPIO_InitTypeDef wdp; 
	__GPIOG_CLK_ENABLE(); 
	wdp.Speed = GPIO_SPEED_HIGH;
	wdp.Pull = 0;// GPIO_PULLDOWN | GPIO_PULLUP;
	wdp.Pin = WD_PIN;

	wdp.Mode = GPIO_MODE_INPUT;
	HAL_GPIO_Init(WD_PORT, &wdp); 

}

//////////////////////////////////////////
// restart the WD timer
void BSPWDKick() 
{
	volatile int i; 
	HAL_GPIO_WritePin(WD_PORT, WD_PIN, GPIO_PIN_SET); 
	for (i = 0; i < 10; i++); 
	HAL_GPIO_WritePin(WD_PORT, WD_PIN, GPIO_PIN_RESET); 
}

static void I2Cx_Error(uint8_t Addr)
{
	BSPI2CDeInit(); 
	BSPI2CInit(); 
}


void BSPI2CInit()
{ 
	I2C_HandleTypeDef *hi2c = &hI2CHandle; 
	hi2c->Instance             = I2Cx;
  
  hi2c->Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
  hi2c->Init.ClockSpeed      = 100000;
  hi2c->Init.DualAddressMode = I2C_DUALADDRESS_DISABLED;
  hi2c->Init.DutyCycle       = I2C_DUTYCYCLE_16_9;
  hi2c->Init.GeneralCallMode = I2C_GENERALCALL_DISABLED;
  hi2c->Init.NoStretchMode   = I2C_NOSTRETCH_DISABLED;
  hi2c->Init.OwnAddress1     = 0;
  hi2c->Init.OwnAddress2     = 0;

	HAL_I2C_Init(hi2c); 
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  /*##-1- Enable GPIO Clocks #################################################*/
  /* Enable GPIO TX/RX clock */
  I2Cx_SCL_GPIO_CLK_ENABLE();
  I2Cx_SDA_GPIO_CLK_ENABLE();
  
  /*##-2- Configure peripheral GPIO ##########################################*/  
  /* I2C TX GPIO pin configuration  */
  GPIO_InitStruct.Pin       = I2Cx_SCL_PIN;
  GPIO_InitStruct.Mode      = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull      = GPIO_PULLUP;
  GPIO_InitStruct.Speed     = GPIO_SPEED_FAST;
  GPIO_InitStruct.Alternate = I2Cx_SCL_AF;
  HAL_GPIO_Init(I2Cx_SCL_GPIO_PORT, &GPIO_InitStruct);
    
  /* I2C RX GPIO pin configuration  */
  GPIO_InitStruct.Pin = I2Cx_SDA_PIN;
  GPIO_InitStruct.Alternate = I2Cx_SDA_AF;
  HAL_GPIO_Init(I2Cx_SDA_GPIO_PORT, &GPIO_InitStruct);
  
  /*##-3- Enable I2C peripheral Clock ########################################*/
  /* Enable I2C1 clock */
  I2Cx_CLK_ENABLE(); 
}

/**
  * @brief I2C MSP De-Initialization 
  *        This function frees the hardware resources used in this example:
  *          - Disable the Peripheral's clock
  *          - Revert GPIO, DMA and NVIC configuration to their default state
  * @param hi2c: I2C handle pointer
  * @retval None
  */


void BSPI2CDeInit()
{
	I2C_HandleTypeDef *hi2c = &hI2CHandle; 
  /*##-1- Reset peripherals ##################################################*/
  I2Cx_FORCE_RESET();
  I2Cx_RELEASE_RESET();

  /*##-2- Disable peripherals and GPIO Clocks ################################*/
  /* Configure I2C Tx as alternate function  */
  HAL_GPIO_DeInit(I2Cx_SCL_GPIO_PORT, I2Cx_SCL_PIN);
  /* Configure I2C Rx as alternate function  */
  HAL_GPIO_DeInit(I2Cx_SDA_GPIO_PORT, I2Cx_SDA_PIN);
}

///////////////////////////////////////////////////////////////////////////
// ST USB stack start
// for details consult ST docs
USBD_HandleTypeDef* BSPUSBInit()
{
	memset(&s_USBD_Device, 0, sizeof(USBD_HandleTypeDef));
	USBD_StatusTypeDef resi = USBD_Init(&s_USBD_Device, &WinUSBComm_Desc, 0);	
	USBD_StatusTypeDef resr = USBD_RegisterClass(&s_USBD_Device, &USBD_WinUSBComm_ClassDriver);

	if (resi || resr) 
		return NULL; 
	return &s_USBD_Device; 

}

HAL_StatusTypeDef BSPUSBStart()
{
	if (USBD_Start(&s_USBD_Device) == USBD_OK)
		return HAL_OK; 
	return HAL_ERROR;
}

#define DAQGPIONUM 22
DAQGPIO gpios[] = 
{
	{ GPIOD, GPIO_PIN_11}, {GPIOD, GPIO_PIN_12}, {GPIOD, GPIO_PIN_12},
	{ GPIOG, GPIO_PIN_3 }, {GPIOG, GPIO_PIN_13}, { GPIOG, GPIO_PIN_14}, 
	{ GPIOJ, GPIO_PIN_0 }, { GPIOJ, GPIO_PIN_1}, { GPIOJ, GPIO_PIN_2}, { GPIOJ, GPIO_PIN_3 }, { GPIOJ, GPIO_PIN_4},{ GPIOJ, GPIO_PIN_5}, { GPIOJ, GPIO_PIN_6}, { GPIOJ, GPIO_PIN_7}, { GPIOJ, GPIO_PIN_11},
	{ GPIOK, GPIO_PIN_1 }, { GPIOK, GPIO_PIN_2}, { GPIOK,  GPIO_PIN_3}, { GPIOK,  GPIO_PIN_4}, { GPIOK,  GPIO_PIN_5}, { GPIOK,  GPIO_PIN_7}, 
}; 

HAL_StatusTypeDef BSPSetGPIOByNum(uint8_t num, uint8_t val)
{
	if (num < 0 || num > DAQGPIONUM)
		return HAL_ERROR; 
	HAL_GPIO_WritePin(gpios[num].port, gpios[num].pin, val ? GPIO_PIN_SET : GPIO_PIN_RESET); 			
	return  HAL_OK; 
}

HAL_StatusTypeDef BSPGPIOInit()
{
	GPIO_InitTypeDef GPIO_Struct; 
	__GPIOD_CLK_ENABLE(); 
	GPIO_Struct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_Struct.Speed = GPIO_SPEED_HIGH;
	GPIO_Struct.Pull = GPIO_NOPULL;
	GPIO_Struct.Pin = GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13; 
	HAL_GPIO_Init(GPIOD, &GPIO_Struct); 

	GPIO_Struct.Pin = GPIO_PIN_3 | GPIO_PIN_13 | GPIO_PIN_14; 
	__GPIOG_CLK_ENABLE();
	HAL_GPIO_Init(GPIOG, &GPIO_Struct); 

	GPIO_Struct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7; 
	__GPIOJ_CLK_ENABLE(); 
	HAL_GPIO_Init(GPIOJ, &GPIO_Struct);

	GPIO_Struct.Pin = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_7; 
	__GPIOK_CLK_ENABLE(); 
	HAL_GPIO_Init(GPIOK, &GPIO_Struct);

	return HAL_OK; 

}

//////////////////////////////////////////////////////////////////
// cpld reset and fifo master reset. Issued before and after every 
// acquisition loop
HAL_StatusTypeDef BSPResetFifoAndCPLD()
{
	int i;
	HAL_GPIO_WritePin(FIFO_RESET_PORT, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(FIFO_RESET_PORT, GPIO_PIN_2, GPIO_PIN_SET); 
	HAL_GPIO_WritePin(FIFO_RESET_PORT, FIFO_RESET_PRS, GPIO_PIN_SET);
	HAL_GPIO_WritePin(FIFO_RESET_PORT, FIFO_RESET_MRS, GPIO_PIN_RESET);
//	HAL_GPIO_WritePin(FIFO_RESET_PORT, FIFO_RESET_PRS, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(CPLD_RESET_PORT, CPLD_RESET_PIN, GPIO_PIN_RESET); //reset CPLD together with FIFO

	for(i=0; i<15000; i++) {}
	HAL_GPIO_WritePin(FIFO_RESET_PORT, FIFO_RESET_MRS, GPIO_PIN_SET);
	//HAL_GPIO_WritePin(FIFO_RESET_PORT, FIFO_RESET_PRS, GPIO_PIN_SET);
	HAL_GPIO_WritePin(CPLD_RESET_PORT, CPLD_RESET_PIN, GPIO_PIN_SET); //end reset CPLD
}

/////////////////////////////////////////////
// Insert CPU Version to EEPROM addresses 13, 14 (5/4/17)
HAL_StatusTypeDef BSPVerCpu(char CpuVer1, char CpuVer2) 
{
	uint16_t CpuData[] = { CpuVer1, CpuVer2 };
	uint16_t ReadCpuData[2] ;
	uint16_t CpuAdd[] = { 13, 14 };
	uint8_t n = 1;
	BSPEERead(CpuAdd[0], &ReadCpuData[0], &n); 
	if (ReadCpuData[0] != CpuData[0])         //Write to EEPROM only at the first time runnig (5/4/17)
	{
		HAL_Delay(100);
		BSPEEWrite(CpuAdd[0], &CpuData[0], &n);
	}
	HAL_Delay(100);
	BSPEERead(CpuAdd[1], &ReadCpuData[1], &n);
	if (ReadCpuData[1] != CpuData[1])        //Write to EEPROM only at the first time runnig (5/4/17)
	{
		HAL_Delay(100);
		BSPEEWrite(CpuAdd[1], &CpuData[1], &n);
	}
		
}