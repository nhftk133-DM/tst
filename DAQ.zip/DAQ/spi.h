#ifndef __SPI_H__
#define __SPIH__
#include "stm32f4xx_hal.h"
#include <stm32f4xx_hal_rcc.h>

#define DAQ_MAX_SPI                       SPI3
#define DAQ_MAX_SPI_CLK_ENABLE()                __HAL_RCC_SPI4_CLK_ENABLE()
#define DAQ_MAX_SPI_SCK_GPIO_CLK_ENABLE()       __GPIOB_CLK_ENABLE()
#define DAQ_MAX_SPI_MISO_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE() 
#define DAQ_MAX_SPI_MOSI_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE() 
#define DAQ_MAX_SPI_NSS_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOA_CLK_ENABLE() 

#define DAQ_MAX_SPI_FORCE_RESET()               __HAL_RCC_SPI4_FORCE_RESET()
#define DAQ_MAX_SPI_RELEASE_RESET()             __HAL_RCC_SPI4_RELEASE_RESET()

/* Definition for SPIx Pins */
#define DAQ_MAX_SPI_SCK_PIN        GPIO_PIN_3
#define DAQ_MAX_SPI_SCK_PORT       GPIOB
#define DAQ_MAX_SCK_AF             GPIO_AF6_SPI3
#define DAQ_MAX_MISO_PIN           GPIO_PIN_6
#define DAQ_MAX_MISO_PORT          GPIOA
#define DAQ_MAX_MISO_AF            GPIO_AF6_SPI3
#define DAQ_MAX_MOSI_PIN           GPIO_PIN_7
#define DAQ_MAX_MOSI_PORT          GPIOA
#define DAQ_MAX_MOSI_AF            GPIO_AF6_SPI3
#define DAQ_MAX_NSS_PIN            GPIO_PIN_4
#define DAQ_MAX_NSS_PORT           GPIOA

void BSPMAX_SPIIinit();
HAL_StatusTypeDef BSPMAX_SPIIinitWriteRead(uint32_t *ww, uint32_t *rw);  

#endif