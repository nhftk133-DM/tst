#ifndef __FW_VERSION_H__
#define __FW_VERSION_H__
#define DAQ_FW_VERSION 342
#endif