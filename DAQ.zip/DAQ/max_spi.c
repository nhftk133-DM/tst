#include "max_spi.h"

static SPI_HandleTypeDef hSpi_MaxHandle; 

///////////////////////////////////////////////////////////
// SPI interface parameters definition
HAL_StatusTypeDef BSPMAX_SPIIinit()
{
  HAL_StatusTypeDef r;
  hSpi_MaxHandle.Instance               = DAQ_MAX_SPI;
  hSpi_MaxHandle.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hSpi_MaxHandle.Init.Direction         = SPI_DIRECTION_2LINES;
  hSpi_MaxHandle.Init.CLKPhase          = SPI_PHASE_2EDGE;
  hSpi_MaxHandle.Init.CLKPolarity       = SPI_POLARITY_HIGH;
  hSpi_MaxHandle.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLED;
  hSpi_MaxHandle.Init.CRCPolynomial     = 7;
  hSpi_MaxHandle.Init.DataSize          = SPI_DATASIZE_16BIT;
  hSpi_MaxHandle.Init.FirstBit          = SPI_FIRSTBIT_MSB;
  hSpi_MaxHandle.Init.NSS               = SPI_NSS_SOFT;
  hSpi_MaxHandle.Init.TIMode            = SPI_TIMODE_DISABLED; 
  hSpi_MaxHandle.Init.Mode				= SPI_MODE_MASTER;

  r = HAL_SPI_Init(&hSpi_MaxHandle);
	//SPI connection BIT
	//Write p twice and check that on the second time it is also read back. 
	//Only bits 31-28 are relevant for the test
  uint32_t p = 0x90000000;
  uint32_t s; 
  BSPMAX_SPIIinitWriteRead(&p, &s); 
  if ( (BSPMAX_SPIIinitWriteRead(&p, &s) == HAL_OK) && (s & p) == p) 
	  return HAL_OK; 
  return HAL_ERROR; 
}

///////////////////////////////////////////////////////////////////////////////////
//Simultaneously reads and writes 32 bits from and to the CPLD
//The NSS is handled by SW, and there are two of them

HAL_StatusTypeDef BSPMAX_SPIIinitWriteRead(uint32_t *ww, uint32_t *rw)
{
	HAL_StatusTypeDef r; 
	GPIO_InitTypeDef GPIO_InitStruct; 
	GPIO_InitStruct.Pin       = DAQ_MAX_NSS_PIN;
	GPIO_InitStruct.Mode      = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull      = GPIO_PULLUP;
	GPIO_InitStruct.Speed     = GPIO_SPEED_FAST;
	HAL_GPIO_Init(DAQ_MAX_NSS_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin		  = DAQ_MAX_NSS_PIN2; 
	HAL_GPIO_Init(DAQ_MAX_NSS_PORT2, &GPIO_InitStruct);


	HAL_GPIO_WritePin(DAQ_MAX_NSS_PORT,  DAQ_MAX_NSS_PIN, GPIO_PIN_SET);  
	HAL_GPIO_WritePin(DAQ_MAX_NSS_PORT2, DAQ_MAX_NSS_PIN2, GPIO_PIN_SET);  


	HAL_GPIO_WritePin(DAQ_MAX_NSS_PORT,  DAQ_MAX_NSS_PIN, GPIO_PIN_RESET); 
	HAL_GPIO_WritePin(DAQ_MAX_NSS_PORT2, DAQ_MAX_NSS_PIN2, GPIO_PIN_RESET); 
	//word swap
	r =  HAL_SPI_TransmitReceive(&hSpi_MaxHandle, ((uint8_t*)ww)+2, ((uint8_t*)rw)+2, 1, 1000);
	r +=  HAL_SPI_TransmitReceive(&hSpi_MaxHandle, ((uint8_t*)ww), ((uint8_t*)rw), 1, 1000);

	HAL_GPIO_WritePin(DAQ_MAX_NSS_PORT,  DAQ_MAX_NSS_PIN, GPIO_PIN_SET);
	HAL_GPIO_WritePin(DAQ_MAX_NSS_PORT2, DAQ_MAX_NSS_PIN2, GPIO_PIN_SET);

	return r; 
}
