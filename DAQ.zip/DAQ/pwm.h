#ifndef __PWM_H__
#define __PWM_H__
#include <stm32f4xx_hal.h>
#include <stm32f4xx_hal_tim.h>
#include <stm32f4xx_hal_rcc.h>
#include "missingdefs.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* User can use this section to tailor TIMx instance used and associated 
   resources */
/* Definition for TIMx clock resources */


#define PWM_TIMER                        TIM1
#define PWM_CLK_ENABLE()                __TIM1_CLK_ENABLE()

/* Definition for USARTx Pins */
#define PWM_GPIO_PORT GPIOA
#define PWM_CHANNEL_GPIO_CLK_ENABLE()       __GPIOA_CLK_ENABLE()
#define PWM_GPIO_PIN		              GPIO_PIN_8

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim); 

#define PWM_COUNTER TIM2
#define PWM_COUNTER_CLK_ENABLE() __TIM2_CLK_ENABLE(); 

#endif //__PWM_H__